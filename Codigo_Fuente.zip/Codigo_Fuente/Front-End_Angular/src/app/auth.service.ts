import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from "rxjs";


@Injectable({
  providedIn: 'root'
})
export class AuthService {
  // el BehaviorSubject que nos permitirá guardar el estado de login
  //tendrá un estado inicial booleano según lo que retorne checkToken
  isLogin = new BehaviorSubject<boolean>(this.checkToken());

  //método que nos permitirá chequear si existe un token, en tal
  //caso retornará true
  private checkToken() : boolean {
    // return !!localStorage.getItem('token');
    return true;
  }

  //método que nos permite establecer el token en el almacenamiento local
  //y enviar una señal al BehaviorSubject para establecer su nuevo valor en
  //true para indicar que estamos logueados
  login(tipo:string, nombre:string, documento:string) : void {
    localStorage.setItem('tipo', tipo);
    localStorage.setItem('nombre', nombre);
    localStorage.setItem('documento', documento);
    this.isLogin.next(true);
  }

  controlsesion(){
    if(localStorage.getItem('nombre')){
      this.isLogin.next(true);
    }
  }

  //método que nos permite recuperar el nombre del usuario
  //del BehaviorSubject userName
  getCourrentUser() : string {
    return localStorage.getItem('nombre');
  }

  //Metodo para obtener el tipo de usuario logeado
  getTipoUser() : string {
    return localStorage.getItem('tipo');
  }

  //método que nos permite eliminar el nombre de usuario
  // del BehaviorSubject userName
  private deleteCourrentUser() : void {
    localStorage.removeItem('nombre');
  }


  //método que nos permite romover el token almacenado y el nombre del
  //usuario actual y enviar una señal al BehaviorSubject para establecer
  //su nuevo valor, en este caso false para indicar que no estamos logueados
  logout() : void {
    localStorage.removeItem('nombre');
    localStorage.removeItem('tipo');
    this.deleteCourrentUser();
    this.isLogin.next(false);
  }

  //método que nos retorna el BehaviorSubject cómo un observable
  isLoggedIn() : Observable<boolean> {
    return this.isLogin.asObservable();
  }
}
