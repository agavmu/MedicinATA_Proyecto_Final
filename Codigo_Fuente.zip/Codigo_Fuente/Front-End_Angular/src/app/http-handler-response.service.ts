import { Injectable } from '@angular/core';
import { AuthService } from './auth.service'
import { Router } from '@angular/router';
import Swal from 'sweetalert2/dist/sweetalert2.js';  

@Injectable({
  providedIn: 'root'
})
export class HttpHandlerResponseService {

  constructor(private route: Router) { 

  }

  protocol(response){
    switch (response.status) {
      case 200:
          if (response.body.tipo === 1){
            this.route.navigate(['/listClients']);
          }else if(response.body.tipo === 2){
            this.route.navigate(['/home'])
          }else if(response.body.tipo === 3){
            this.route.navigate(['/home'])
          }else {
            this.route.navigate(['/home'])
          }
        break;

      case 401:
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'No has iniciado sesión. Por favor verifica tu usuario y contraseña e inténtalo de nuevo',
          })

        break;
    
      default:
        break;
    }
  }
}
