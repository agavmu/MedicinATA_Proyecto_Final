import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ClientService } from '../client.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { HttpHandlerResponseService } from '../http-handler-response.service';
import Swal from 'sweetalert2/dist/sweetalert2.js';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})


export class LoginComponent implements OnInit {

  form: FormGroup;
  load: boolean = true;

  constructor(private httpHandlerResponse: HttpHandlerResponseService,
    private fb: FormBuilder,
    private client: ClientService,
    public auth: AuthService, private route: Router) { }

  ngOnInit(): void {
    this.form = this.fb.group({
      email: ['', Validators.email],
      clave: ['', Validators.required]
    });
  }

  async onSubmit() {

    if (this.form.valid) {
      this.load = false;
      this.client.postRequest('http://localhost:8080/medicinata_ws/webapi/usuarios/validarlogin', {
        email: this.form.value.email,
        clave: this.form.value.clave
      }).subscribe(

        (response: any) => {
          this.load = true;
          const { nombre, tipo, documento } = response.body
          //se almacena el tipo de usuario en el almacenamiento de sesion
          this.auth.login(tipo, nombre, documento);
          //se almacena el nombre del usuario en el almacenamiento de
          //sesion
          Swal.fire({
            icon: 'success',
            title:
              'Bienvenido a nuestro sistema',
            showConfirmButton: false,
            toast: true,
            position: "top-end",
            timer: 2000,
            timerProgressBar: true
          });
          //navegamos de nuevo al home, esta vez como usuario
          //logueado
          this.httpHandlerResponse.protocol(response);
        },
        (error) => {
          this.load = true;
          this.httpHandlerResponse.protocol(error);

          console.log(this.load, error.status);

        })

    } else {
      Swal.fire({
        icon: 'question',
        title:
          'Algo salio mal?',
        showConfirmButton: false,
        timer: 2000,
        timerProgressBar: true
      });
    }
  }

}
