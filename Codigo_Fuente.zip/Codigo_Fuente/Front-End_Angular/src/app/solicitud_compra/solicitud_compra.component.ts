import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { timer } from 'rxjs';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-solicitud_compra',
  templateUrl: './solicitud_compra.component.html',
  styleUrls: ['./solicitud_compra.component.css']
})
export class SolicompraComponent implements OnInit {

  constructor( private route: Router) { }
  
  ngOnInit(): void {
  }

  comprar(){
    Swal.fire({
      icon: 'success',
      title:'compra realizada',
      timer: 5000,
      timerProgressBar: true,
    })
    this.route.navigate(['/home']);
  }
}
