import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-change_password',
  templateUrl: './change_password.component.html',
  styleUrls: ['./change_password.component.css']
})
export class ChangePasswordComponent implements OnInit {     

  constructor(private client: ClientService, public auth: AuthService, private route: Router) { }

  ngOnInit(): void {

    this.auth.controlsesion();

  }

}