import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BienvenidaComponent } from "./bienvenida/bienvenida.component";
import { LoginComponent } from "./login/login.component";
import { HomeComponent } from "./home/home.component";
import { RegistrouserComponent } from "./registrouser/registrouser.component";
import { RegisclientComponent } from "./regisclient/regisclient.component";
import { RegisadminComponent } from "./regisadmin/regisadmin.component";
import { ClientesComponent } from "./lista_clientes/lista_clientes.component";
import { MedicamentosComponent } from "./lista_medicamentos/lista_medicamentos.component";
import { AcercadeComponent } from "./acercade/acercade.component";
import { MedicamentosDispComponent } from './medicamentos_disp/medicamentos_disp.component';
import { StatsComponent } from './estadisticas_med/estadisticas_med.component';
import { NotifyComponent } from './notificaciones_solic/notificaciones_solic.component';
import { SolicompraComponent } from './solicitud_compra/solicitud_compra.component';
import { ProfileClientComponent } from './profile_client/profile_client.component';
import { ImgComponent } from './img/img.component';
import { AddMedicineComponent } from './add_medicine/add_medicine.component';
import { ChangePasswordComponent } from './change_password/change_password.component';
import { HomeGuard } from './guards/home.guard';
import { RegistroGuard } from './guards/registro.guard';
import { ClientesGuard } from './guards/clientes.guard';
import { MedicamentosGuard } from './guards/medicamentos.guard';

const routes: Routes = [
  { path: '', component: BienvenidaComponent },
  { path: 'login', component: LoginComponent },
  { path: 'home', component: HomeComponent, canActivate: [HomeGuard] },
  { path: 'registrouser', component: RegistrouserComponent },
  { path: 'regisclient', component: RegisclientComponent, canActivate: [RegistroGuard] },
  { path: 'regisadmin', component: RegisadminComponent, canActivate: [RegistroGuard] },
  { path: 'listClients', component: ClientesComponent, canActivate: [ClientesGuard] },
  { path: 'listMedicines', component: MedicamentosComponent, canActivate: [MedicamentosGuard]  },
  { path: 'aboutus', component: AcercadeComponent, canActivate: [HomeGuard] },
  { path: 'img', component: ImgComponent },
  { path: 'stats', component: StatsComponent, canActivate: [HomeGuard] },
  { path: 'notifications', component: NotifyComponent, canActivate: [HomeGuard] },
  { path: 'solicitud', component: SolicompraComponent, canActivate: [HomeGuard]},
  { path: 'addMedicine', component: AddMedicineComponent, canActivate: [MedicamentosGuard] },
  { path: 'profileClient', component: ProfileClientComponent},
  { path: 'medicinesDisp', component: MedicamentosDispComponent, canActivate: [HomeGuard] },
  { path: 'changePassword', component: ChangePasswordComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
