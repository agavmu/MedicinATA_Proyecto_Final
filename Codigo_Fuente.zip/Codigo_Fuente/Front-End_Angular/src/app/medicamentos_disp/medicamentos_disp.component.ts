import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { ClientService } from '../client.service';

@Component({
  selector: 'app-medicamentos_disp',
  templateUrl: './medicamentos_disp.component.html',
  styleUrls: ['./medicamentos_disp.component.css']
})
export class MedicamentosDispComponent implements OnInit {

  medicamentos: any[];

  constructor( private route: Router, public auth: AuthService, private client: ClientService) {
    this.medicamentos = [];
    this.medicamentos['detalles'] = [];
   }
  
  ngOnInit(): void {

    this.client.getRequest('http://localhost:8080/medicinata_ws/webapi/medicamentos/medicamentos',
    ).subscribe((result: any) => {
      this.medicamentos = (result.body);
      console.log('Medicamentos', this.medicamentos)
    });
  }

}
