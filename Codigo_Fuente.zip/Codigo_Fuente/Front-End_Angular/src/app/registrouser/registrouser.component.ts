import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service'
import { AuthService } from '../auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2/dist/sweetalert2.js';


@Component({
  selector: 'app-registrouser',
  templateUrl: './registrouser.component.html',
  styleUrls: ['./registrouser.component.css']
})
export class RegistrouserComponent implements OnInit {

  form: FormGroup;
  validator = true;

  constructor(private fb: FormBuilder, private client: ClientService, private route: Router, public auth : AuthService ) { }

  ngOnInit() {
    this.form = this.fb.group({
      documento: ['', Validators.required],
      nombre: ['', Validators.required],
      apellido: ['', Validators.required],
      telefono: ['', Validators.required],
      email: ['', Validators.email],
      clave: ['', Validators.required],
      tipo: ['', Validators.required]
    })
    this.getTipoUsuario();
  }

  getTipoUsuario(){
    const usuario=localStorage.getItem('tipo');
    parseInt(usuario)
    if(usuario === null) {
      this.validator=false;
    }
  }

  async onSubmit() {

    if (this.form.valid) {

      console.log(this.form.valid);

      this.auth.controlsesion();
      
      this.client.postRequest('http://localhost:8080/medicinata_ws/webapi/usuarios/registrar', {
        documento: String(this.form.value.documento),
        nombre: this.form.value.nombre,
        apellido: this.form.value.apellido,
        telefono: String(this.form.value.telefono),
        email: this.form.value.email,
        clave: this.form.value.clave,
        tipo: this.form.value.tipo
      },

        localStorage.getItem("token")
      ).subscribe(

        (response: any) => {
          if (response.status === 200) {
            Swal.fire({
              icon: 'success',
              title: 'Bienvenido',
              timer: 2000,
              timerProgressBar: true,
              toast: true,
              position: 'top-end',
              showConfirmButton: false,
            })
            this.route.navigate(['/']);
          } else {
            Swal.fire({
              icon: 'question',
              title: 'Hubo un error',
              timer: 2000,
              timerProgressBar: true,
            })
          }
        }, (error) => {
          Swal.fire({
            icon: 'warning',
            title: 'Hubo un error, intente nuevamente',
            timer: 2000,
            timerProgressBar: true,
          })
        });
    } else {
      Swal.fire({
        icon: 'question',
        title: 'Verifique el formulario e intente nuevamente',
        timer: 2000,
        timerProgressBar: true,
      })
    }
  }
}
