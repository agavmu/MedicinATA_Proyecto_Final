package com.medicinata.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.medicinata.entidades.MedicamentosClientes;
import com.medicinata.util.JPAUtil;

public class MedicamentosClientesDao implements Serializable {

	private static final long serialVersionUID = 1L;
	
	EntityManager entityManager=JPAUtil.getEntityManagerFactory().createEntityManager();
	
	public String registrarMedicamentosCliente(MedicamentosClientes medicamentosClientes) {
		String resp = "";
		
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(medicamentosClientes);
			entityManager.getTransaction().commit();
			
			resp = "Registro exitoso";
		}catch(Exception e) {
			e.printStackTrace();
			resp = "Hubo un error, intente nuevamente";
		}
		return resp;
	}
	
	public List<MedicamentosClientes> consultarListaMedicamentosClientes() {

		List<MedicamentosClientes> listaMedicamentosClientes = new ArrayList<MedicamentosClientes>();
		Query query = entityManager.createQuery("SELECT m FROM MedicamentosClientes m");
		listaMedicamentosClientes = query.getResultList();

		return listaMedicamentosClientes;
	}
	
	public void close() {
		entityManager.close();
		JPAUtil.shutdown();
	}
}
