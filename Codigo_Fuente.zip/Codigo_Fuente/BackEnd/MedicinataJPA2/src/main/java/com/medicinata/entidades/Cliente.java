package com.medicinata.entidades;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "clientes")
public class Cliente implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "documento", nullable = false, length = 20)
	private String documento;

	@Column(name = "razonsocial", nullable = false, length = 45)
	private String razonsocial;

	@Column(name = "telefono", nullable = false, length = 20)
	private String telefono;

	@Column(name = "email", nullable = false, length = 45)
	private String email;

	@Column(name = "direccion", nullable = false, length = 100)
	private String direccion;
	
	@Column(name = "clave")
	private String clave;

	@OneToMany(mappedBy = "farmacia", cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	private List<MedicamentosClientes> listaMedicamentos;

	@OneToMany(mappedBy = "ajuste", cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	private List<AjusteInv> listaAjuste;

	public Cliente() {
		this.listaMedicamentos = new ArrayList<MedicamentosClientes>();
		this.listaAjuste = new ArrayList<AjusteInv>();
	}

	public Cliente(String documento, String razonsocial, String telefono, String email, String direccion, String clave) {
		super();
		this.documento = documento;
		this.razonsocial = razonsocial;
		this.telefono = telefono;
		this.email = email;
		this.direccion = direccion;
		this.clave = clave;
		this.listaMedicamentos = new ArrayList<MedicamentosClientes>();
		this.listaAjuste = new ArrayList<AjusteInv>();
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public String getRazonsocial() {
		return razonsocial;
	}

	public void setRazonsocial(String razonsocial) {
		this.razonsocial = razonsocial;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	
	public String getClave() {
		return clave;
	}
	
	public void setClave(String clave) {
		this.clave = clave;
	}

	public List<MedicamentosClientes> getListaMedicamentos() {
		return listaMedicamentos;
	}

	public void setListaMedicamentos(List<MedicamentosClientes> listaMedicamentos) {
		this.listaMedicamentos = listaMedicamentos;
	}

	public List<AjusteInv> getListaAjuste() {
		return listaAjuste;
	}

	public void setListaAjuste(List<AjusteInv> listaAjuste) {
		this.listaAjuste = listaAjuste;
	}

	@Override
	public String toString() {
		return "Cliente [documento=" + documento + ", razonsocial=" + razonsocial + ", telefono=" + telefono
				+ ", email=" + email + ", direccion=" + direccion + ", listaMedicamentos=" + listaMedicamentos
				+ ", listaAjuste=" + listaAjuste + "]";
	}

}
