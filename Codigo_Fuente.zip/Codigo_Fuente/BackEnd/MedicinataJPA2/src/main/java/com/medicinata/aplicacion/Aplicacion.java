package com.medicinata.aplicacion;

import java.util.List;

import javax.swing.JOptionPane;

import com.medicinata.dao.UsuarioDao;
import com.medicinata.entidades.Usuario;

public class Aplicacion {

	UsuarioDao miUsuarioDao = new UsuarioDao();

	public void iniciar() {

		String menu = "Menu de opciones \n\n";
		menu += "1- Registrar usuario\n";
		menu += "2- consultar usuario\n";
		menu += "3- consultar lista de usuarios\n";
		menu += "4- actualizar usuario\n";
		menu += "5- eliminar usuario\n";
		menu += "6- salir\n";
//		menu += "7- consultar medicamento\n";
//		menu += "8- consultar lista de medicamentos\n";
//		menu += "9- actualizar medicamento\n";
//		menu += "10- eliminar medicamento\n";

		int opc = 0;

		while (opc != 10) {
			opc = Integer.parseInt(JOptionPane.showInputDialog(menu));

			switch (opc) {
			case 1:
				registrar();
				break;
			case 2:
				consultar();
				break;
			case 3:
				consultarLista();
				break;
			case 4:
				actualizar();
				break;
			case 5:
				eliminar();
				break;
			case 6:
				miUsuarioDao.close();
				break;
//			case 6:
//				registrarMedicamento();
//				break;
//			case 7:
//				consultarMedicamento();
//				break;
//			case 8:
//				consultarListaMedicamentos();
//				break;
//			case 9:
//				actualizarMedicamento();
//				break;
//			case 10:
//				eliminarMedicamento();
//				break;
			}
		}

	}

	private void registrar() {
		Usuario miUsuario = new Usuario();

		miUsuario.setDocumento(JOptionPane.showInputDialog("Ingrese el Documento: "));
		miUsuario.setNombre(JOptionPane.showInputDialog("Ingrese el Nombre: "));
		miUsuario.setEmail(JOptionPane.showInputDialog("Ingrese el Correo: "));
		miUsuario.setClave(JOptionPane.showInputDialog("Ingrese la Password: "));
		miUsuario.setTelefono(JOptionPane.showInputDialog("Ingrese el Telefono: "));
		miUsuario.setTipo(Integer.parseInt(JOptionPane.showInputDialog("Ingrese el tipo de usuario: ")));

		System.out.println(miUsuario);
	}

	private void consultar() {
		String documento = JOptionPane.showInputDialog("Ingrese el documento a consultar: ");

		Usuario miUsuario = miUsuarioDao.consultarUsuario(documento);

		if (miUsuario != null) {
			System.out.println(miUsuario);
			System.out.println();
		} else {
			System.out.println();
			System.out.println("No se encontro el usuario");
		}
		System.out.println();
	}

	private void consultarLista() {
		System.out.println("Lista de usuarios");
		List<Usuario> listaUsuarios = miUsuarioDao.consultarLista();

		for (Usuario usuario : listaUsuarios) {
			System.out.println(usuario);
		}

	}

	private void actualizar() {
		String documento = JOptionPane.showInputDialog("Ingrese el documento a consultar: ");
		Usuario miUsuario = miUsuarioDao.consultarUsuario(documento);

		if (miUsuario != null) {
			System.out.println(miUsuario);
			System.out.println();
			miUsuario.setNombre(JOptionPane.showInputDialog("Ingrese el Nombre: "));
			miUsuario.setTelefono(JOptionPane.showInputDialog("Ingrese el telefono: "));

			System.out.println(miUsuarioDao.actualizarUsuario(miUsuario));
			System.out.println();
		} else {
			System.out.println();
			System.out.println("No se encontro el usuario");
		}
		System.out.println();
	}
		
	
		

	private void eliminar() {
		String documento = JOptionPane.showInputDialog("Ingrese el documento a consultar: ");
		Usuario miUsuario = miUsuarioDao.consultarUsuario(documento);

		if (miUsuario != null) {
			System.out.println(miUsuario);
			System.out.println();

			System.out.println(miUsuarioDao.eliminarUsuario(miUsuario));
			System.out.println();
		} else {
			System.out.println();
			System.out.println("No se encontro el usuario");
		}
		System.out.println();
	}

//	private void registrarMedicamento() {
//
//	}
//
//	private void consultarMedicamento() {
//
//	}
//
//	private void consultarListaMedicamentos() {
//
//	}
//
//	private void actualizarMedicamento() {
//
//	}
//
//	private void eliminarMedicamento() {
//
//	}

}
