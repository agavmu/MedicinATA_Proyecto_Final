package com.medicinata.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.medicinata.entidades.Cum;
import com.medicinata.util.JPAUtil;

public class CumDao {
	EntityManager entityManager = JPAUtil.getEntityManagerFactory().createEntityManager();

	public String registrarMedicamento(Cum miCum) {
		String resp = "";

		try {
			entityManager.getTransaction().begin();
			entityManager.persist(miCum);
			entityManager.getTransaction().commit();

			resp = "Medicamento registrado";

		} catch (Exception e) {
			System.out.println("No se registro el medicamento");
			e.printStackTrace();
			resp = "Hubo un problema";
		}
		return resp;
	}

	public Cum consultarMedicamento(String codigo) {
		Cum miCum = entityManager.find(Cum.class, codigo);
		try {
			if (miCum != null) {
				return miCum;
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public List<Cum> consultarListaMedicamentos() {

		List<Cum> listaMedicamentos = new ArrayList<Cum>();
		Query query = entityManager.createQuery("SELECT c FROM Cum c");
		listaMedicamentos = query.getResultList();

		return listaMedicamentos;
	}

	public String actualizarMedicamento(Cum miCum) {
		
		String resp = "";
		
		try {			
			System.out.println("ingrese a actualizar medicamento");
			entityManager.getTransaction().begin();
			entityManager.merge(miCum);
			entityManager.getTransaction().commit();

			resp = "Medicamento actualizado";
		} catch(Exception e) {
			e.printStackTrace();
			resp = "Hubo un error, Verifique los datos e Intente nuevamente";
		}

		return resp;
	}

	public String eliminarMedicamento(Cum miCum) {
		String resp = "";

		try {
			entityManager.getTransaction().begin();
			entityManager.remove(miCum);
			entityManager.getTransaction().commit();

			resp = "Medicamento eliminado";
		} catch (Exception e) {
			e.printStackTrace();
			resp = "Hubo un error, Verifique los datos e Intente nuevamente";
		}
		return resp;
	}

	public void close() {
		entityManager.close();
		JPAUtil.shutdown();
	}
}
