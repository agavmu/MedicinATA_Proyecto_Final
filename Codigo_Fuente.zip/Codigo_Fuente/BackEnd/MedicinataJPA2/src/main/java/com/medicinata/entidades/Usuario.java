package com.medicinata.entidades;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "usuarios")
public class Usuario implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "documento", nullable = false, length = 20)
	private String documento;

	@Column(name = "nombre", nullable = false, length = 45)
	private String nombre;
	
	@Column(name = "apellido", nullable = false, length = 150)
	private String apellido;

	@Column(name = "clave", nullable = false, length = 64)
	private String clave;
	
	@Column(name = "email", nullable = false, length = 60)
	private String email;

	@Column(name = "telefono", length = 30)
	private String telefono;

	@Column(name = "tipousuario", nullable = false)
	private int tipo;
	
	@OneToMany(mappedBy = "ajuste2",cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	private List<AjusteInv> listaAjuste;

	public Usuario() {
		this.listaAjuste = new ArrayList<AjusteInv>();
	}

	public Usuario(String documento, String nombre, String apellido, String clave, String email,
			String telefono, int tipo) {
		super();
		this.documento = documento;
		this.nombre = nombre;
		this.apellido = apellido;
		this.clave = clave;
		this.email = email;
		this.telefono = telefono;
		this.tipo = tipo;
		this.listaAjuste = new ArrayList<AjusteInv>();
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public int getTipo() {
		return tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	
	public List<AjusteInv> getListaAjuste() {
		return listaAjuste;
	}

	public void setListaAjuste(List<AjusteInv> listaAjuste) {
		this.listaAjuste = listaAjuste;
	}

	@Override
	public String toString() {
		return "Usuario [documento=" + documento + ", nombre=" + nombre + ", apellido=" + apellido + ", clave=" + clave
				+ ", email=" + email + ", telefono=" + telefono + ", tipo=" + tipo + ", listaAjuste=" + listaAjuste
				+ "]";
	}
	
}
