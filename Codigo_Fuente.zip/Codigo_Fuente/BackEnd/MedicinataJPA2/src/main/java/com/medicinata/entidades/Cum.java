package com.medicinata.entidades;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "cum")
public class Cum implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "codigo")
	private Long codigo;

	@Column(name = "nombre", nullable = false, length = 250)
	private String nombre;

	@Column(name = "concentracion", nullable = false, length = 45)
	private String concentracion;

	@Column(name = "descripcion", nullable = false, length = 250)
	private String descripcion;

	@Column(name = "observaciones", nullable = false, length = 1000)
	private String observaciones;

	@Column(name = "img", nullable = false, length = 250)
	private String img;

	@OneToMany(mappedBy = "medicamento", cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	private List<MedicamentosClientes> listaMedicamentos;

	@OneToMany(mappedBy = "ajustedetalle2", cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	private List<AjusteInvDetalle> listaAjusteDetalle;

	public Cum() {
		this.listaMedicamentos = new ArrayList<MedicamentosClientes>();
		this.listaAjusteDetalle = new ArrayList<AjusteInvDetalle>();
	}

	public Cum(String nombre, String concentracion, String descripcion, String observaciones, String img) {
		super();
		this.nombre = nombre;
		this.concentracion = concentracion;
		this.descripcion = descripcion;
		this.observaciones = observaciones;
		this.img = img;
		this.listaMedicamentos = new ArrayList<MedicamentosClientes>();
		this.listaAjusteDetalle = new ArrayList<AjusteInvDetalle>();
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getConcentracion() {
		return concentracion;
	}

	public void setConcentracion(String concentracion) {
		this.concentracion = concentracion;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public List<MedicamentosClientes> getListaMedicamentos() {
		return listaMedicamentos;
	}

	public void setListaMedicamentos(List<MedicamentosClientes> listaMedicamentos) {
		this.listaMedicamentos = listaMedicamentos;
	}

	public List<AjusteInvDetalle> getListaAjusteDetalle() {
		return listaAjusteDetalle;
	}

	public void setListaAjusteDetalle(List<AjusteInvDetalle> listaAjusteDetalle) {
		this.listaAjusteDetalle = listaAjusteDetalle;
	}

	@Override
	public String toString() {
		return "Cum [codigo=" + codigo + ", nombre=" + nombre + ", concentracion=" + concentracion + ", descripcion="
				+ descripcion + ", observaciones=" + observaciones + ", listaMedicamentos=" + listaMedicamentos + "]";
	}

}
