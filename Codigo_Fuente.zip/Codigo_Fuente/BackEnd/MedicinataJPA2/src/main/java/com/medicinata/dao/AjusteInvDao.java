package com.medicinata.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.medicinata.entidades.AjusteInv;
import com.medicinata.util.JPAUtil;

public class AjusteInvDao {
	EntityManager entityManager = JPAUtil.getEntityManagerFactory().createEntityManager();	
	
	public String registrarCompra(AjusteInv medicamento) {
		String resp = "";
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(medicamento);
			entityManager.getTransaction().commit();
			
			resp ="Compra realizada satisfactoriamente";
		}catch(Exception e) {
			e.printStackTrace();
			resp="No se pudo realizar la compra";
		}
		return resp;
	}
	
	public AjusteInv consultarAjuste(Long idajuste) {
		AjusteInv miAjuste = entityManager.find(AjusteInv.class, idajuste);
		try {
			if (miAjuste != null) {
				return miAjuste;
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public List<AjusteInv> consultarListaAjustes() {
		
		List<AjusteInv> listaAjustes = new ArrayList<AjusteInv>();
		Query query = entityManager.createQuery("SELECT a FROM AjusteInv a");
		listaAjustes = query.getResultList();
	
		return listaAjustes;
	}

	public String actualizarAjuste(AjusteInv miAjuste) {
		
		String resp = "";
		
		try {
			entityManager.getTransaction().begin();
			entityManager.merge(miAjuste);
			entityManager.getTransaction().commit();
			
			resp = "Ajuste Actualizado";
		}catch(Exception e){
			e.printStackTrace();
			resp = "Hubo un error, Verifique los datos e intente nuevamente";
		}
		return resp;
	}
	
	public void close() {
		entityManager.close();
		JPAUtil.shutdown();
	}
}
