package com.medicinata.entidades;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ajustesinventariodetalle")
public class AjusteInvDetalle implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idajustesinvdetalle")
	private Long idajusteinvdet;
	
	@Column(name = "cantidad")
	private int cantidad;
	
	@Column(name = "precio")
	private float precio;
	
	@ManyToOne
	@JoinColumn(name = "idajuste", referencedColumnName = "idajuste")
	private AjusteInv ajustedetalle;

	@ManyToOne
	@JoinColumn(name = "codigocum", referencedColumnName = "codigo")
	private Cum ajustedetalle2;
	
	public AjusteInvDetalle() {

	}

	public AjusteInvDetalle(int cantidad, float precio, AjusteInv ajusteDetalle,
			Cum ajusteDetalle2) {
		super();
		this.cantidad = cantidad;
		this.precio = precio;
		this.ajustedetalle = ajusteDetalle;
		this.ajustedetalle2 = ajusteDetalle2;
	}

	public Long getIdajusteinvdet() {
		return idajusteinvdet;
	}

	public void setIdajusteinvdet(Long idajusteinvdet) {
		this.idajusteinvdet = idajusteinvdet;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public AjusteInv getAjustedetalle() {
		return ajustedetalle;
	}

	public void setAjustedetalle(AjusteInv ajustedetalle) {
		this.ajustedetalle = ajustedetalle;
	}

	public Cum getAjustedetalle2() {
		return ajustedetalle2;
	}

	public void setAjustedetalle2(Cum ajustedetalle2) {
		this.ajustedetalle2 = ajustedetalle2;
	}

	@Override
	public String toString() {
		return "AjusteInvDetalle [idajusteinvdet=" + idajusteinvdet + ", cantidad=" + cantidad + ", precio=" + precio
				+ ", ajusteDetalle=" + ajustedetalle + ", ajusteDetalle2=" + ajustedetalle2 + "]";
	}
	
}
