package com.medicinata.aplicacion;

public class Principal {

	public static void main (String[] args) {
		Aplicacion miAplicacion = new Aplicacion();
		miAplicacion.iniciar();
	}
	
}
