package com.medicinata.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.medicinata.entidades.Usuario;
import com.medicinata.util.JPAUtil;

public class UsuarioDao {
	EntityManager entityManager = JPAUtil.getEntityManagerFactory().createEntityManager();

	public String registrarUsuario(Usuario miUsuario) {
		System.out.println(miUsuario);
		String resp = "";

		try {
			entityManager.getTransaction().begin();
			entityManager.persist(miUsuario);
			entityManager.getTransaction().commit();

			resp = "Usuario registrado";

		} catch (Exception e) {
			System.out.println("No se registro la persona");
			e.printStackTrace();
		}

		return resp;
	}

	public Usuario consultarUsuario(String Documento) {

		Usuario miUsuario = entityManager.find(Usuario.class, Documento);
		try {
			if (miUsuario != null) {
				return miUsuario;
			} else {
				return null;
			}			
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	public List<Usuario> consultarLista() {

		List<Usuario> listaUsuarios = new ArrayList<Usuario>();
		Query query = entityManager.createQuery("SELECT u FROM Usuario u");
		listaUsuarios = query.getResultList();

		return listaUsuarios;
	}

	public String actualizarUsuario(Usuario miUsuario) {
		
		String resp ="";

		try {			
			entityManager.getTransaction().begin();
			entityManager.merge(miUsuario);
			entityManager.getTransaction().commit();

			resp = "Usuario actualizado";
		} catch(Exception e) {
			e.printStackTrace();
			resp ="Hubo un error, Verifique los datos e Intente nuevamente";
		}

		return resp;
	}

	public String eliminarUsuario(Usuario miUsuario) {

		String resp = "";
		try {
			entityManager.getTransaction().begin();
			entityManager.remove(miUsuario);
			entityManager.getTransaction().commit();

			resp = "Usuario eliminado";
		} catch (Exception e) {
			e.printStackTrace();
			resp = "No se puede eliminar, verifique que no tenga medicamentos asociados";
		}
		return resp;
	}

	public void close() {
		entityManager.close();
		JPAUtil.shutdown();
	}
}
