package com.medicinata.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.medicinata.entidades.AjusteInv;
import com.medicinata.entidades.AjusteInvDetalle;
import com.medicinata.util.JPAUtil;

public class AjusteInvDetalleDao {
	EntityManager entityManager = JPAUtil.getEntityManagerFactory().createEntityManager();

	public AjusteInvDetalle consultarAjusteDetalle(Long idajusteinvdet) {
		AjusteInvDetalle miAjusteDetalle = entityManager.find(AjusteInvDetalle.class, idajusteinvdet);
		try {
			if (miAjusteDetalle != null) {
				return miAjusteDetalle;
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public List<AjusteInvDetalle> consultarListaAjustesDetalles() {

		List<AjusteInvDetalle> listaAjustesDetalle = new ArrayList<AjusteInvDetalle>();
		Query query = entityManager.createQuery("SELECT a FROM AjusteInvDetalle a");
		listaAjustesDetalle = query.getResultList();

		return listaAjustesDetalle;
	}

	public String actualizarAjusteDetalle(AjusteInvDetalle miAjusteDetalle) {

		String resp = "";

		try {
			entityManager.getTransaction().begin();
			entityManager.merge(miAjusteDetalle);
			entityManager.getTransaction().commit();

			resp = "Ajuste detalle Actualizado";
		} catch (Exception e) {
			e.printStackTrace();
			resp = "Hubo un error, Verifique los datos e intente nuevamente";
		}
		return resp;
	}

	public void close() {
		entityManager.close();
		JPAUtil.shutdown();
	}

}
