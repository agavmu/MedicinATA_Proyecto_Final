package com.medicinata.entidades;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "ajustesinventario")
public class AjusteInv implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idajuste")
	private Long idajuste;
	
	@Column(name = "fecha")
	private LocalDate fecha;
	
	@Column(name = "precio")
	private float precio;
	
	@Column(name = "observaciones", nullable = false, length = 1000)
	private String observaciones;
	
	@ManyToOne
	@JoinColumn(name = "cliente", referencedColumnName = "documento")
	private Cliente ajuste;

	@ManyToOne
	@JoinColumn(name = "usuario", referencedColumnName = "documento")
	private Usuario ajuste2;
	
	@OneToMany(mappedBy = "ajustedetalle",cascade = {CascadeType.PERSIST, CascadeType.MERGE})
	private List<AjusteInvDetalle> listaAjusteDetalle;
	
	public AjusteInv() {
		this.listaAjusteDetalle = new ArrayList<AjusteInvDetalle>();
	}

	public AjusteInv(Long idajuste, LocalDate fecha, float precio, String observaciones, Cliente ajuste, Usuario ajuste2) {
		super();
		this.idajuste = idajuste;
		this.fecha = fecha;
		this.precio = precio;
		this.observaciones = observaciones;
		this.ajuste = ajuste;
		this.ajuste2 = ajuste2;
		this.listaAjusteDetalle = new ArrayList<AjusteInvDetalle>();
	}

	public Long getIdajuste() {
		return idajuste;
	}

	public void setIdajuste(Long idajuste) {
		this.idajuste = idajuste;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public Cliente getAjuste() {
		return ajuste;
	}

	public void setAjuste(Cliente ajuste) {
		this.ajuste = ajuste;
	}

	public Usuario getAjuste2() {
		return ajuste2;
	}

	public void setAjuste2(Usuario ajuste2) {
		this.ajuste2 = ajuste2;
	}
	
	public List<AjusteInvDetalle> getListaAjusteDetalle() {
		return listaAjusteDetalle;
	}

	public void setListaAjusteDetalle(List<AjusteInvDetalle> listaAjusteDetalle) {
		this.listaAjusteDetalle = listaAjusteDetalle;
	}

	@Override
	public String toString() {
		return "AjusteInv [idajuste=" + idajuste + ", fecha=" + fecha + ", precio=" + precio + ", observaciones="
				+ observaciones + ", ajuste=" + ajuste + ", ajuste2=" + ajuste2 + "]";
	}

}
