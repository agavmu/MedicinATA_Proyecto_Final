package com.medicinata.entidades;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "medicamentos_clientes")
public class MedicamentosClientes implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "idmedicamento")
	private Long idmedicamento;
	
	@Column(name = "cantidad")
	private int cantidad;
	
	@Column(name = "precio", nullable = false, length = 45)
	private String precio;
	
	@ManyToOne
	@JoinColumn(name = "cliente", referencedColumnName = "documento")
	private Cliente farmacia;

	@ManyToOne
	@JoinColumn(name = "codigocum", referencedColumnName = "codigo")
	private Cum medicamento;
	
	public MedicamentosClientes() {
		
	}

	public MedicamentosClientes(int cantidad, String precio, Cliente farmacia, Cum medicamento) {
		super();
		this.cantidad = cantidad;
		this.precio = precio;
		this.farmacia = farmacia;
		this.medicamento = medicamento;
	}



	public Long getIdmedicamento() {
		return idmedicamento;
	}

	public void setIdmedicamento(Long idmedicamento) {
		this.idmedicamento = idmedicamento;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public String getPrecio() {
		return precio;
	}

	public void setPrecio(String precio) {
		this.precio = precio;
	}

	public Cliente getFarmacia() {
		return farmacia;
	}

	public void setFarmacia(Cliente farmacia) {
		this.farmacia = farmacia;
	}

	public Cum getMedicamento() {
		return medicamento;
	}

	public void setMedicamento(Cum medicamento) {
		this.medicamento = medicamento;
	}

	@Override
	public String toString() {
		return "MedicamentosClientes [idmedicamento=" + idmedicamento + ", cantidad=" + cantidad + ", precio=" + precio
				+ ", Farmacias=" + farmacia + ", medicamento=" + medicamento + "]";
	}
	
}
