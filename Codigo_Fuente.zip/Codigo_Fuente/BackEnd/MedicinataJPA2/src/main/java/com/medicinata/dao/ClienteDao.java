package com.medicinata.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.medicinata.entidades.Cliente;
import com.medicinata.util.JPAUtil;

public class ClienteDao {
	EntityManager entityManager = JPAUtil.getEntityManagerFactory().createEntityManager();

	public String registrarCliente(Cliente miCliente) {
		String resp = "";

		try {
			entityManager.getTransaction().begin();
			entityManager.persist(miCliente);
			entityManager.getTransaction().commit();

			resp = "Cliente registrado";

		} catch (Exception e) {
			e.printStackTrace();
			resp = "Hubo un problema, intente nuevamente";
		}
		return resp;
	}

	public Cliente consultarCliente(String documento) {
		Cliente miCliente = entityManager.find(Cliente.class, documento);
		try {
			if (miCliente != null) {
				return miCliente;
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public List<Cliente> consultarListaClientes() {

		List<Cliente> listaClientes = new ArrayList<Cliente>();
		Query query = entityManager.createQuery("SELECT c FROM Cliente c");
		listaClientes = query.getResultList();

		return listaClientes;
	}

	public String actualizarCliente(Cliente miCliente) {

		String resp = "";

		try {
			entityManager.getTransaction().begin();
			entityManager.merge(miCliente);
			entityManager.getTransaction().commit();

			resp = "Cliente actualizado";
		} catch (Exception e) {
			e.printStackTrace();
			resp = "Hubo un error, Verifique los datos e Intente nuevamente";
		}

		return resp;
	}

	public String eliminarCliente(Cliente miCliente) {
		String resp = "";

		try {
			entityManager.getTransaction().begin();
			entityManager.remove(miCliente);
			entityManager.getTransaction().commit();

			resp = "Cliente eliminado";
		} catch (Exception e) {
			e.printStackTrace();
			resp = "Hubo un error, Verifique los datos e Intente nuevamente";
		}
		return resp;
	}
	
	public void close() {
		entityManager.close();
		JPAUtil.shutdown();
	}

}
