package org.medicinata.ws.dao;

import java.util.List;

import org.medicinata.ws.adapter.UsuarioAdapter;
import org.medicinata.ws.vo.UsuarioVo;

import com.medicinata.entidades.Usuario;

public class UsuarioDao {

	public UsuarioDao() {
		// UsuariosUtilidades.inicarLista();
	}

	public UsuarioVo consultarLogin(String email, String clave) {
		com.medicinata.dao.UsuarioDao miUsuarioDaoJpa = new com.medicinata.dao.UsuarioDao();
		
		UsuarioAdapter miUsuarioAdapter = new UsuarioAdapter();
		
		UsuarioVo usuario = null;
		
		List<Usuario> listaUsuariosJpa = miUsuarioDaoJpa.consultarLista();
		List<UsuarioVo> listaUsuarios = miUsuarioAdapter.asignarListaUsuarios(listaUsuariosJpa);
		
		for (UsuarioVo obj : listaUsuarios) {
			if (obj.getEmail().equals(email) && obj.getClave().equals(clave)) {
				usuario = obj;
				break;
			}
		}
		return usuario;
	}

	public String registrarUsuario(Usuario usuario) {
		com.medicinata.dao.UsuarioDao miUsuarioDaoJpa = new com.medicinata.dao.UsuarioDao();

		String mensaje = miUsuarioDaoJpa.registrarUsuario(usuario);

		return mensaje;
	}

	public UsuarioVo consultaIndividual(String documento) {
		com.medicinata.dao.UsuarioDao miUsuarioDaoJpa = new com.medicinata.dao.UsuarioDao();

		Usuario miUsuarioJpa = miUsuarioDaoJpa.consultarUsuario(documento);

		UsuarioAdapter miUsuarioAdapter = new UsuarioAdapter();

		UsuarioVo miUsuario = miUsuarioAdapter.asignarUsuario(miUsuarioJpa);

		//miUsuarioDaoJpa.close();

		return miUsuario;
	}
	
	public List<UsuarioVo> obtenerListaUsuarios() {
		com.medicinata.dao.UsuarioDao miUsuarioDaoJpa = new com.medicinata.dao.UsuarioDao();
		
		UsuarioAdapter miUsuarioAdapter = new UsuarioAdapter();
		
		List<Usuario> listaUsuariosJpa = miUsuarioDaoJpa.consultarLista();
		List<UsuarioVo> listaUsuarios = miUsuarioAdapter.asignarListaUsuarios(listaUsuariosJpa);
		
		return listaUsuarios;
	}

	public String actualizarUsuario(String documento, Usuario usuario) {
		com.medicinata.dao.UsuarioDao miUsuarioDaoJpa = new com.medicinata.dao.UsuarioDao();

		String resp = "";

		if (miUsuarioDaoJpa.consultarUsuario(documento) != null) {
			resp = miUsuarioDaoJpa.actualizarUsuario(usuario);
		}
		return resp;
	}

	public String eliminarUsuario(String documento) {
		com.medicinata.dao.UsuarioDao miUsuarioDaoJpa = new com.medicinata.dao.UsuarioDao();

		String resp = "El usuario no existe o lo ingreso incorrectamente";
		Usuario usuario = miUsuarioDaoJpa.consultarUsuario(documento);

		if (usuario != null) {
			resp = miUsuarioDaoJpa.eliminarUsuario(usuario);
		}
		return resp;
	}

}
