package org.medicinata.ws.dao;

import java.util.List;

import org.medicinata.ws.adapter.AjusteInvDetalleAdapter;
import org.medicinata.ws.vo.AjusteInvDetalleVo;

import com.medicinata.entidades.AjusteInvDetalle;

public class AjusteInvDetalleDao {
	
	public AjusteInvDetalleVo consultaAjusteDetalle(Long idajusteinvdetalle) {
		com.medicinata.dao.AjusteInvDetalleDao miAjusteDetalleDaoJpa = new com.medicinata.dao.AjusteInvDetalleDao();

		AjusteInvDetalle miAjusteInvDetalleJpa = miAjusteDetalleDaoJpa.consultarAjusteDetalle(idajusteinvdetalle);

		AjusteInvDetalleAdapter miAjusteInvDetalleAdapter = new AjusteInvDetalleAdapter();

		AjusteInvDetalleVo miAjusteDetalle = miAjusteInvDetalleAdapter.asignarAjusteDetalle(miAjusteInvDetalleJpa);

		return miAjusteDetalle;
	}

	public List<AjusteInvDetalleVo> obtenerListaAjustesDetalle() {
		com.medicinata.dao.AjusteInvDetalleDao miAjusteInvDetalleDaoJpa = new com.medicinata.dao.AjusteInvDetalleDao();
		
		AjusteInvDetalleAdapter miAjusteInvDetalleAdapter = new AjusteInvDetalleAdapter();
		
		List<AjusteInvDetalle> listaAjusteDetalleJpa = miAjusteInvDetalleDaoJpa.consultarListaAjustesDetalles();
		List<AjusteInvDetalleVo> listaAjusteDetalle = miAjusteInvDetalleAdapter.asignarListaAjustesDetalle(listaAjusteDetalleJpa);
		
		return listaAjusteDetalle;
	}

	public String actualizarAjusteDetalle(Long idajusteinvdetalle, AjusteInvDetalle ajusteinvdetalle) {
		com.medicinata.dao.AjusteInvDetalleDao miAjusteInvDetalleDaoJpa = new com.medicinata.dao.AjusteInvDetalleDao();

		String resp = "";

		if (miAjusteInvDetalleDaoJpa.consultarAjusteDetalle(idajusteinvdetalle) != null) {
			resp = miAjusteInvDetalleDaoJpa.actualizarAjusteDetalle(ajusteinvdetalle);
		} else {
			resp = "Hubo un error, Verifique los datos e intente nuevamente";
		}
		return resp;
	}

}
