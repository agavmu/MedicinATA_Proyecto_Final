package org.medicinata.ws.vo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AjusteInvVo {
	
	private Long idajuste;
	private LocalDate fecha;
	private float precio;
	private String observaciones;
	private ClienteVo ajuste;
	private UsuarioVo ajuste2;
	private List<AjusteInvDetalleVo> listaAjustesDetalle;
	
	public AjusteInvVo() {
		this.listaAjustesDetalle = new ArrayList<AjusteInvDetalleVo>();
	}

	public AjusteInvVo(Long idajuste, LocalDate fecha, float precio, String observaciones, ClienteVo ajuste,
			UsuarioVo ajuste2) {
		super();
		this.idajuste = idajuste;
		this.fecha = fecha;
		this.precio = precio;
		this.observaciones = observaciones;
		this.ajuste = ajuste;
		this.ajuste2 = ajuste2;
		this.listaAjustesDetalle = new ArrayList<AjusteInvDetalleVo>();
	}

	public Long getIdajuste() {
		return idajuste;
	}

	public void setIdajuste(Long idajuste) {
		this.idajuste = idajuste;
	}

	public LocalDate getFecha() {
		return fecha;
	}
	
	public void setFecha(LocalDate fecha) {
		this.fecha = fecha;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public ClienteVo getAjuste() {
		return ajuste;
	}

	public void setAjuste(ClienteVo ajuste) {
		this.ajuste = ajuste;
	}

	public UsuarioVo getAjuste2() {
		return ajuste2;
	}

	public void setAjuste2(UsuarioVo ajuste2) {
		this.ajuste2 = ajuste2;
	}

	public List<AjusteInvDetalleVo> getListaAjustesDetalle() {
		return listaAjustesDetalle;
	}

	public void setListaAjustesDetalle(List<AjusteInvDetalleVo> listaAjustesDetalle) {
		this.listaAjustesDetalle = listaAjustesDetalle;
	}
}
