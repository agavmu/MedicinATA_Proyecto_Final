package org.medicinata.ws.adapter;

import java.util.ArrayList;
import java.util.List;

import org.medicinata.ws.vo.CumVo;
import org.medicinata.ws.vo.MedicamentosClientesVo;

import com.medicinata.entidades.MedicamentosClientes;

public class MedicamentosClientesAdapter {
	
	public MedicamentosClientesVo asignarMedicamento(MedicamentosClientes m) {
		MedicamentosClientesVo miMedicamentosClientes = null;
		if (m != null) {
			miMedicamentosClientes = new MedicamentosClientesVo();
			miMedicamentosClientes.setIdmedicamento(m.getIdmedicamento());
			miMedicamentosClientes.setCantidad(m.getCantidad());
			miMedicamentosClientes.setPrecio(m.getPrecio());
			
			CumVo medicamento = new CumVo();
			medicamento.setCodigo(m.getMedicamento().getCodigo());
			medicamento.setNombre(m.getMedicamento().getNombre());
			medicamento.setConcentracion(m.getMedicamento().getConcentracion());
			
			miMedicamentosClientes.setMedicamento(medicamento);
		}
		return miMedicamentosClientes;
	}
	
	public List<MedicamentosClientesVo> asignarListaMedicamentos(List<MedicamentosClientes> lista) {
		List<MedicamentosClientesVo> miListaMedicamentos = new ArrayList<MedicamentosClientesVo>();
		
		for (int i = 0; i < lista.size(); i++) {
			miListaMedicamentos.add(asignarMedicamento(lista.get(i)));
		}
		return miListaMedicamentos;
	}

}
