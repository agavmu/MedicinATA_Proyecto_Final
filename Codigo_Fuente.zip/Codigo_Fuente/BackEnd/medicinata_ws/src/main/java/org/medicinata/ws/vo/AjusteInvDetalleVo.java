package org.medicinata.ws.vo;

public class AjusteInvDetalleVo {
	
	private Long idajusteinvdet;
	private int cantidad;
	private float precio;
	private AjusteInvVo ajustedetalle;
	private CumVo ajustedetalle2;
	
	public AjusteInvDetalleVo() {
		
	}

	public AjusteInvDetalleVo(Long idajusteinvdet, int cantidad, float precio, AjusteInvVo ajustedetalle,
			CumVo ajustedetalle2) {
		super();
		this.idajusteinvdet = idajusteinvdet;
		this.cantidad = cantidad;
		this.precio = precio;
		this.ajustedetalle = ajustedetalle;
		this.ajustedetalle2 = ajustedetalle2;
	}

	public Long getIdajusteinvdet() {
		return idajusteinvdet;
	}

	public void setIdajusteinvdet(Long idajusteinvdet) {
		this.idajusteinvdet = idajusteinvdet;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public float getPrecio() {
		return precio;
	}

	public void setPrecio(float precio) {
		this.precio = precio;
	}

	public AjusteInvVo getAjustedetalle() {
		return ajustedetalle;
	}

	public void setAjustedetalle(AjusteInvVo ajustedetalle) {
		this.ajustedetalle = ajustedetalle;
	}

	public CumVo getAjustedetalle2() {
		return ajustedetalle2;
	}

	public void setAjustedetalle2(CumVo ajustedetalle2) {
		this.ajustedetalle2 = ajustedetalle2;
	}

	@Override
	public String toString() {
		return "AjusteInvDetalleVo [idajusteinvdet=" + idajusteinvdet + ", cantidad=" + cantidad + ", precio=" + precio
				+ ", ajustedetalle=" + ajustedetalle + ", ajustedetalle2=" + ajustedetalle2 + "]";
	}

}
