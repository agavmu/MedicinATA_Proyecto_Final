package org.medicinata.ws.dao;

import java.util.List;

import org.medicinata.ws.adapter.MedicamentosClientesAdapter;
import org.medicinata.ws.vo.MedicamentosClientesVo;

import com.medicinata.entidades.MedicamentosClientes;

public class MedicamentosClientesDao {
	
	
	public String registrarMedicamento(MedicamentosClientes medicamentosClientes) {
		com.medicinata.dao.MedicamentosClientesDao miMedDaoJpa = new com.medicinata.dao.MedicamentosClientesDao();

		String mensaje = miMedDaoJpa.registrarMedicamentosCliente(medicamentosClientes);

		return mensaje;
	}
	
	public List<MedicamentosClientesVo> obtenerListaMedicamentos() {
		com.medicinata.dao.MedicamentosClientesDao miMedDaoJpa = new com.medicinata.dao.MedicamentosClientesDao();
		
		MedicamentosClientesAdapter miMedAdapter = new MedicamentosClientesAdapter();
		
		List<MedicamentosClientes> listaMedJpa = miMedDaoJpa.consultarListaMedicamentosClientes();
		List<MedicamentosClientesVo> listaMed = miMedAdapter.asignarListaMedicamentos(listaMedJpa);
		
		return listaMed;
	}

}
