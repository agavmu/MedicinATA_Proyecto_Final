package org.medicinata.ws.adapter;

import java.util.ArrayList;
import java.util.List;

import org.medicinata.ws.vo.UsuarioVo;

import com.medicinata.entidades.Usuario;

public class UsuarioAdapter {
	
	public UsuarioVo asignarUsuario(Usuario u) {
		
		UsuarioVo miUsuario=null;
		
		if(u!=null) {
			miUsuario = new UsuarioVo();
			miUsuario.setDocumento(u.getDocumento());
			miUsuario.setNombre(u.getNombre());
			miUsuario.setApellido(u.getApellido());
			miUsuario.setClave(u.getClave());
			miUsuario.setEmail(u.getEmail());
			miUsuario.setTelefono(u.getTelefono());
			miUsuario.setTipo(u.getTipo());
			
			AjusteInvAdapter miAjusteInvAdapter = new AjusteInvAdapter();
			miUsuario.setListaAjustes(miAjusteInvAdapter.asignarListaAjustes(u.getListaAjuste()));
		}
		
		return miUsuario;
	}

	public List<UsuarioVo> asignarListaUsuarios(List<Usuario> listaUsuariosJpa) {
		List<UsuarioVo> lista = new ArrayList<UsuarioVo>();
		
		for(Usuario usuario : listaUsuariosJpa) {
			lista.add(asignarUsuario(usuario));
		}
		return lista;
	}
}
