package org.medicinata.ws.vo;

public class MedicamentosClientesVo {
	
	private Long idmedicamento;
	private int cantidad;
	private String precio;
	private ClienteVo farmacia;
	private CumVo medicamento;
	
	public MedicamentosClientesVo() { 
		
	}
	
	public MedicamentosClientesVo(Long idmedicamento, int cantidad, String precio, ClienteVo farmacia,
			CumVo medicamento) {
		super();
		this.idmedicamento = idmedicamento;
		this.cantidad = cantidad;
		this.precio = precio;
		this.farmacia = farmacia;
		this.medicamento = medicamento;
	}

	public Long getIdmedicamento() {
		return idmedicamento;
	}

	public void setIdmedicamento(Long idmedicamento) {
		this.idmedicamento = idmedicamento;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public String getPrecio() {
		return precio;
	}

	public void setPrecio(String precio) {
		this.precio = precio;
	}

	public ClienteVo getFarmacia() {
		return farmacia;
	}

	public void setFarmacia(ClienteVo farmacia) {
		this.farmacia = farmacia;
	}

	public CumVo getMedicamento() {
		return medicamento;
	}

	public void setMedicamento(CumVo medicamento) {
		this.medicamento = medicamento;
	}

}
