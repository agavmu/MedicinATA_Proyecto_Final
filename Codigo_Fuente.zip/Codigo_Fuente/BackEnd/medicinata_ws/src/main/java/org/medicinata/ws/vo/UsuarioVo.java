package org.medicinata.ws.vo;

import java.util.ArrayList;
import java.util.List;

public class UsuarioVo {

	private String documento;
	private String nombre;
	private String apellido;
	private String clave;
	private String email;
	private String telefono;
	private int tipo;
	private List<AjusteInvVo> listaAjustes;
	
	public UsuarioVo() {
		this.listaAjustes = new ArrayList<AjusteInvVo>();
	}
	
	public UsuarioVo(String documento, String nombre, String apellido,  String clave,
			String email, String telefono, int tipo) {
		super();
		this.documento = documento;
		this.nombre = nombre;
		this.apellido = apellido;
		this.clave = clave;
		this.email = email;
		this.tipo = tipo;	
		this.listaAjustes = new ArrayList<AjusteInvVo>();
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public int getTipo() {
		return tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}

	public List<AjusteInvVo> getListaAjustes() {
		return listaAjustes;
	}

	public void setListaAjustes(List<AjusteInvVo> listaAjustes) {
		this.listaAjustes = listaAjustes;
	}

	@Override
	public String toString() {
		return "UsuarioVo [documento=" + documento + ", nombre=" + nombre + ", clave=" + clave + ", email=" + email
				+ ", telefono=" + telefono + ", tipo=" + tipo + ", listaAjustes=" + listaAjustes + "]";
	}
	
}
