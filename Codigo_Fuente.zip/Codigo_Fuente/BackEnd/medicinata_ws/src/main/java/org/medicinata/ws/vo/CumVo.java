package org.medicinata.ws.vo;

import java.util.ArrayList;
import java.util.List;

public class CumVo {

	private Long codigo;
	private String nombre;
	private String concentracion;
	private String descripcion;
	private String observaciones;
	private String img;
	private List<MedicamentosClientesVo> listaMedicamentos;

	public CumVo() {
		this.listaMedicamentos = new ArrayList<MedicamentosClientesVo>();
	}

	public CumVo(Long codigo, String nombre, String concentracion, String descripcion, String observaciones, String img) {
		super();
		this.codigo = codigo;
		this.nombre = nombre;
		this.concentracion = concentracion;
		this.descripcion = descripcion;
		this.observaciones = observaciones;
		this.img = img;
		this.listaMedicamentos = new ArrayList<MedicamentosClientesVo>();
	}

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getConcentracion() {
		return concentracion;
	}

	public void setConcentracion(String concentracion) {
		this.concentracion = concentracion;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public void setObservaciones(String observacion) {
		this.observaciones = observacion;
	}

	public List<MedicamentosClientesVo> getListaMedicamentos() {
		return listaMedicamentos;
	}

	public void setListaMedicamentos(List<MedicamentosClientesVo> listaMedicamentos) {
		this.listaMedicamentos = listaMedicamentos;
	}

	@Override
	public String toString() {
		return "CumVo [codigo=" + codigo + ", nombre=" + nombre + ", concentracion=" + concentracion + ", descripcion="
				+ descripcion + ", observaciones=" + observaciones + "]";
	}

}