package org.medicinata.ws.rest;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.medicinata.ws.vo.ClienteVo;
import org.medicinata.ws.dao.ClienteDao;

import com.medicinata.entidades.Cliente;

@Path("clientes")
public class ClienteService {

	ClienteDao clienteDao = new ClienteDao();

	// http://localhost:8080/medicinata_ws/webapi/clientes/registrarcliente
	@POST
	@Path("/registrarcliente")
	@Consumes({ MediaType.APPLICATION_JSON })
	public Response registrarCliente(Cliente cliente) {
		try {
			String resp = clienteDao.registrarCliente(cliente);
			if (resp.equals("Cliente registrado")) {
				return Response.ok().entity(cliente).build();
			} else {
				return Response.status(Response.Status.NOT_FOUND).build();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}

	// http://localhost:8080/medicinata_ws/webapi/clientes/cliente/{id}
	@GET
	@Path("/cliente/{documento}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response consutarCliente(@PathParam("documento") String documento) {
		ClienteVo cliente = clienteDao.consultaCliente(documento);
		try {

			if (cliente != null) {
				return Response.ok(cliente).build();
			}
			return Response.status(Response.Status.NOT_FOUND).build();
		} catch (Exception e) {
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
		}
	}

	// http://localhost:8080/medicinata_ws/webapi/clientes/clientes
	@GET
	@Path("/clientes")
	@Produces({ MediaType.APPLICATION_JSON })
	public List<ClienteVo> obtenerListaMedicamentos() {
		return clienteDao.obtenerListaClientes();
	}

	// http://localhost:8080/medicinata_ws/webapi/clientes/{id}
	@PUT
	@Path("/{id}")
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	public Response actualizarCliente(@PathParam("id") String documento, Cliente cliente) {
		try {
			String resp = clienteDao.actualizarCliente(documento, cliente);
			if (resp.equals("Cliente actualizado")) {
				return Response.ok(cliente).build();
			} else {
				return Response.status(Response.Status.NOT_FOUND).build();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}

	// http://localhost:8080/medicinata_ws/webapi/clientes/{id}
	@DELETE
	@Path("/{id}")
	public Response eliminarCliente(@PathParam("id") String documento) {
		try {
			String resp = clienteDao.eliminarCliente(documento);
			if (resp.equals("Cliente eliminado")) {
				return Response.ok().build();
			} else {
				return Response.status(Response.Status.NOT_FOUND).header("header", resp).build();
			}

		} catch (Exception e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}
}
