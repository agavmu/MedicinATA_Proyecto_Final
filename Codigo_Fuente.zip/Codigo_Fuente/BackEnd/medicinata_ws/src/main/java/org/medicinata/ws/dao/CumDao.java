package org.medicinata.ws.dao;

import java.util.List;


import org.medicinata.ws.adapter.CumAdapter;
import org.medicinata.ws.vo.CumVo;

import com.medicinata.entidades.Cum;

public class CumDao {

	public String registrarMedicamento(Cum cum) {
		com.medicinata.dao.CumDao miCumDaoJpa = new com.medicinata.dao.CumDao();

		String mensaje = miCumDaoJpa.registrarMedicamento(cum);

		return mensaje;
	}

	public CumVo consultaIndividual(String codigo) {
		com.medicinata.dao.CumDao miCumDaoJpa = new com.medicinata.dao.CumDao();

		Cum miCumJpa = miCumDaoJpa.consultarMedicamento(codigo);

		CumAdapter miCumAdapter = new CumAdapter();

		CumVo miCum = miCumAdapter.asignarCum(miCumJpa);

		//miCumDaoJpa.close();

		return miCum;
	}

	public String actualizarMedicamento(String codigo, Cum cum) {
		com.medicinata.dao.CumDao miCumDaoJpa = new com.medicinata.dao.CumDao();

		String resp = "";

		if (miCumDaoJpa.consultarMedicamento(codigo) != null) {
			resp = miCumDaoJpa.actualizarMedicamento(cum);
		} else {
			resp = "Hubo un error, Verifique los datos e intente nuevamente";
		}
		return resp;
	}
	
	public List<CumVo> obtenerListaCum() {
		com.medicinata.dao.CumDao miCumDaoJpa = new com.medicinata.dao.CumDao();
		
		CumAdapter miCumAdapter = new CumAdapter();
		
		List<Cum> listaCumJpa = miCumDaoJpa.consultarListaMedicamentos();
		List<CumVo> listaCum = miCumAdapter.asignarListaCum(listaCumJpa);
		
		return listaCum;
	}

	public String eliminarMedicamento(String codigo) {
		com.medicinata.dao.CumDao miCumDaoJpa = new com.medicinata.dao.CumDao();

		String resp = "";

		Cum cum = miCumDaoJpa.consultarMedicamento(codigo);

		if (cum != null) {
			resp = miCumDaoJpa.eliminarMedicamento(cum);
		} else {
			resp ="El medicamento no existe o lo ingreso incorrectamente";
		}
		return resp;
	}

}
