package org.medicinata.ws.dao;

import java.util.List;

import org.medicinata.ws.adapter.AjusteInvAdapter;
import org.medicinata.ws.vo.AjusteInvVo;

import com.medicinata.entidades.AjusteInv;

public class AjusteInvDao {
	
	public String registrarCompra(AjusteInv medicamento) {
		com.medicinata.dao.AjusteInvDao miAjusteInvDaoJpa = new com.medicinata.dao.AjusteInvDao();
		
		String mensaje = miAjusteInvDaoJpa.registrarCompra(medicamento);
		
		return mensaje;
	}
	
	public AjusteInvVo consultaAjuste(Long idajuste) {
		com.medicinata.dao.AjusteInvDao miAjusteDaoJpa = new com.medicinata.dao.AjusteInvDao();

		AjusteInv miAjusteInvJpa = miAjusteDaoJpa.consultarAjuste(idajuste);

		AjusteInvAdapter miAjusteInvAdapter = new AjusteInvAdapter();

		AjusteInvVo miAjuste = miAjusteInvAdapter.asignarAjuste(miAjusteInvJpa);

		return miAjuste;
	}

	public List<AjusteInvVo> obtenerListaAjustes() {
		com.medicinata.dao.AjusteInvDao miAjusteInvDaoJpa = new com.medicinata.dao.AjusteInvDao();
		
		AjusteInvAdapter miAjusteInvAdapter = new AjusteInvAdapter();
		
		List<AjusteInv> listaAjusteJpa = miAjusteInvDaoJpa.consultarListaAjustes();
		List<AjusteInvVo> listaAjuste = miAjusteInvAdapter.asignarListaAjustes(listaAjusteJpa);
		
		return listaAjuste;
	}

	public String actualizarAjuste(Long idajuste, AjusteInv ajusteinv) {
		com.medicinata.dao.AjusteInvDao miAjusteInvDaoJpa = new com.medicinata.dao.AjusteInvDao();

		String resp = "";

		if (miAjusteInvDaoJpa.consultarAjuste(idajuste) != null) {
			resp = miAjusteInvDaoJpa.actualizarAjuste(ajusteinv);
		} else {
			resp = "Hubo un error, Verifique los datos e intente nuevamente";
		}
		return resp;
	}

}
