package org.medicinata.ws.adapter;

import java.util.ArrayList;
import java.util.List;

import org.medicinata.ws.vo.CumVo;

import com.medicinata.entidades.Cum;

public class CumAdapter {

	public CumVo asignarCum(Cum c) {

		CumVo miCum = null;

		if (c != null) {
			miCum = new CumVo();
			miCum.setCodigo(c.getCodigo());
			miCum.setNombre(c.getNombre());
			miCum.setConcentracion(c.getConcentracion());
			miCum.setDescripcion(c.getDescripcion());
			miCum.setObservaciones(c.getObservaciones());
			miCum.setImg(c.getImg());
			
			MedicamentosClientesAdapter miMedCliAdapter = new MedicamentosClientesAdapter();
			miCum.setListaMedicamentos(miMedCliAdapter.asignarListaMedicamentos(c.getListaMedicamentos()));
		}

		return miCum;
	}
	
	public List<CumVo> asignarListaCum(List<Cum> listaCumJpa) {
		List<CumVo> lista = new ArrayList<CumVo>();
		
		for(Cum cum : listaCumJpa) {
			lista.add(asignarCum(cum));
		}
		return lista;
	}
	
}
