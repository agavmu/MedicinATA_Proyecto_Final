package org.medicinata.ws.vo;

import java.util.ArrayList;
import java.util.List;

public class ClienteVo {

	private String documento;
	private String razonsocial;
	private String telefono;
	private String email;
	private String direccion;
	private String clave;
	private List<MedicamentosClientesVo> listaMedicamentos;
	private List<AjusteInvVo> listaAjustes;

	public ClienteVo() {
		this.listaMedicamentos = new ArrayList<MedicamentosClientesVo>();
		this.listaAjustes = new ArrayList<AjusteInvVo>();
	}
	
	public ClienteVo(String documento) {
		this.documento = documento;
	}

	public ClienteVo(String documento, String razonsocial, String telefono, String email, String direccion, String clave) {
		super();
		this.documento = documento;
		this.razonsocial = razonsocial;
		this.telefono = telefono;
		this.email = email;
		this.direccion = direccion;
		this.clave = clave;
		this.listaMedicamentos = new ArrayList<MedicamentosClientesVo>();
		this.listaAjustes = new ArrayList<AjusteInvVo>();
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public String getRazonsocial() {
		return razonsocial;
	}

	public void setRazonsocial(String razonsocial) {
		this.razonsocial = razonsocial;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	
	public String getClave() {
		return clave;
	}
	
	public void setClave(String clave) {
		this.clave = clave;
	}

	public List<MedicamentosClientesVo> getListaMedicamentos() {
		return listaMedicamentos;
	}

	public void setListaMedicamentos(List<MedicamentosClientesVo> listaMedicamentos) {
		this.listaMedicamentos = listaMedicamentos;
	}

	public List<AjusteInvVo> getListaAjustes() {
		return listaAjustes;
	}

	public void setListaAjustes(List<AjusteInvVo> listaAjustes) {
		this.listaAjustes = listaAjustes;
	}

	@Override
	public String toString() {
		return "ClienteVo [documento=" + documento + ", razonsocial=" + razonsocial + ", telefono=" + telefono
				+ ", email=" + email + ", direccion=" + direccion + ", listaMedicamentos=" + listaMedicamentos
				+ ", listaAjustes=" + listaAjustes + "]";
	}

}
