package org.medicinata.ws.adapter;

import java.util.ArrayList;
import java.util.List;

import org.medicinata.ws.vo.ClienteVo;

import com.medicinata.entidades.Cliente;

public class ClienteAdapter {
	
	public ClienteVo asignarCliente(Cliente c) {
		
		ClienteVo miCliente = null;
		
		if (c != null) {
			miCliente = new ClienteVo();
			miCliente.setDocumento(c.getDocumento());
			miCliente.setRazonsocial(c.getRazonsocial());
			miCliente.setTelefono(c.getTelefono());
			miCliente.setEmail(c.getEmail());
			miCliente.setDireccion(c.getDireccion());
			miCliente.setClave(c.getClave());
			
			MedicamentosClientesAdapter miMedicamentosClientesAdapter = new MedicamentosClientesAdapter();
			miCliente.setListaMedicamentos(miMedicamentosClientesAdapter.asignarListaMedicamentos(c.getListaMedicamentos()));
			
			AjusteInvAdapter miAjusteInvAdapter = new AjusteInvAdapter();
			miCliente.setListaAjustes(miAjusteInvAdapter.asignarListaAjustes(c.getListaAjuste()));
		}
		return miCliente;
	}

	public List<ClienteVo> asignarListaClientes(List<Cliente> listaClientesJpa) {
		List<ClienteVo> lista = new ArrayList<ClienteVo>();
		
		for(Cliente cliente : listaClientesJpa) {
			lista.add(asignarCliente(cliente));
		}
		return lista;
	}
	
}
