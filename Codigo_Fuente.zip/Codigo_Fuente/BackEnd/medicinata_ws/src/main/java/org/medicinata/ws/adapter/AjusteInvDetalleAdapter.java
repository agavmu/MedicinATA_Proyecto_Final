package org.medicinata.ws.adapter;

import java.util.ArrayList;
import java.util.List;

import org.medicinata.ws.vo.AjusteInvDetalleVo;
import org.medicinata.ws.vo.AjusteInvVo;
import org.medicinata.ws.vo.CumVo;
import com.medicinata.entidades.AjusteInvDetalle;

public class AjusteInvDetalleAdapter {

	public AjusteInvDetalleVo asignarAjusteDetalle(AjusteInvDetalle a) {

		AjusteInvDetalleVo miAjusteDetalle = null;

		if (a != null) {
			miAjusteDetalle = new AjusteInvDetalleVo();
			miAjusteDetalle.setIdajusteinvdet(a.getIdajusteinvdet());
			miAjusteDetalle.setCantidad(a.getCantidad());
			miAjusteDetalle.setPrecio(a.getPrecio());

			CumVo ajustedetalle2 = new CumVo();
			ajustedetalle2.setCodigo(a.getAjustedetalle2().getCodigo());

			miAjusteDetalle.setAjustedetalle2(ajustedetalle2);

			AjusteInvVo ajustedetalle = new AjusteInvVo();
			ajustedetalle.setIdajuste(a.getAjustedetalle().getIdajuste());

			miAjusteDetalle.setAjustedetalle(ajustedetalle);
		}
		return miAjusteDetalle;
	}

	public List<AjusteInvDetalleVo> asignarListaAjustesDetalle(List<AjusteInvDetalle> lista) {
		List<AjusteInvDetalleVo> listaAjustesDetalle = new ArrayList<AjusteInvDetalleVo>();

		for (int i = 0; i < lista.size(); i++) {
			listaAjustesDetalle.add(asignarAjusteDetalle(lista.get(i)));
		}
		return listaAjustesDetalle;
	}
	
}
