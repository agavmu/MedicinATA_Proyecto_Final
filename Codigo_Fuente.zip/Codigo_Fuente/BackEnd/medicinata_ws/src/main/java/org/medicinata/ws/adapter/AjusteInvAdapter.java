package org.medicinata.ws.adapter;

import java.util.ArrayList;
import java.util.List;

import org.medicinata.ws.vo.AjusteInvVo;
import org.medicinata.ws.vo.ClienteVo;
import org.medicinata.ws.vo.UsuarioVo;
import com.medicinata.entidades.AjusteInv;

public class AjusteInvAdapter {

	public AjusteInvVo asignarAjuste(AjusteInv a) {

		AjusteInvVo miAjuste = null;

		if (a != null) {
			miAjuste = new AjusteInvVo();
			miAjuste.setIdajuste(a.getIdajuste());
			miAjuste.setFecha(a.getFecha());
			miAjuste.setPrecio(a.getPrecio());
			miAjuste.setObservaciones(a.getObservaciones());

			UsuarioVo ajuste2 = new UsuarioVo();
			ajuste2.setDocumento(a.getAjuste2().getDocumento());

			miAjuste.setAjuste2(ajuste2);

			ClienteVo ajuste = new ClienteVo();
			ajuste.setDocumento(a.getAjuste().getDocumento());

			miAjuste.setAjuste(ajuste);
			
			AjusteInvDetalleAdapter miAjusteInvDetalleAdapter = new AjusteInvDetalleAdapter();
			miAjuste.setListaAjustesDetalle(miAjusteInvDetalleAdapter.asignarListaAjustesDetalle(a.getListaAjusteDetalle()));
		}
		return miAjuste;
	}

	public List<AjusteInvVo> asignarListaAjustes(List<AjusteInv> lista) {
		List<AjusteInvVo> listaAjustes = new ArrayList<AjusteInvVo>();

		for (int i = 0; i < lista.size(); i++) {
			listaAjustes.add(asignarAjuste(lista.get(i)));
		}
		return listaAjustes;
	}

}
