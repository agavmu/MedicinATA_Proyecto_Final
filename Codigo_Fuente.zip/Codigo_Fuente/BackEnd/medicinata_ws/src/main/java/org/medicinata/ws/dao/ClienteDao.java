package org.medicinata.ws.dao;

import java.util.List;

import org.medicinata.ws.adapter.ClienteAdapter;
import org.medicinata.ws.vo.ClienteVo;

import com.medicinata.entidades.Cliente;

public class ClienteDao {
	
	public String registrarCliente (Cliente cliente) {
		com.medicinata.dao.ClienteDao miClienteDaoJpa = new com.medicinata.dao.ClienteDao();
		
		String mensaje = miClienteDaoJpa.registrarCliente(cliente);
		
		return mensaje;
	}
	
	public ClienteVo consultaCliente(String documento) {
		com.medicinata.dao.ClienteDao miClienteDaoJpa = new com.medicinata.dao.ClienteDao();

		Cliente miClienteJpa = miClienteDaoJpa.consultarCliente(documento);

		ClienteAdapter miClienteAdapter = new ClienteAdapter();

		ClienteVo miClienteVo = miClienteAdapter.asignarCliente(miClienteJpa);

		return miClienteVo;
	}
	
	public List<ClienteVo> obtenerListaClientes() {
		com.medicinata.dao.ClienteDao miClienteDaoJpa = new com.medicinata.dao.ClienteDao();
		
		ClienteAdapter miClienteAdapter = new ClienteAdapter();
		
		List<Cliente> listaClientesJpa = miClienteDaoJpa.consultarListaClientes();
		List<ClienteVo> listaClientes = miClienteAdapter.asignarListaClientes(listaClientesJpa);
		
		return listaClientes;
	}
	
	public String actualizarCliente(String documento, Cliente cliente) {
		com.medicinata.dao.ClienteDao miClienteDaoJpa = new com.medicinata.dao.ClienteDao();

		String resp = "";

		if (miClienteDaoJpa.consultarCliente(documento) != null) {
			resp = miClienteDaoJpa.actualizarCliente(cliente);
		} else {
			resp = "Hubo un error, Verifique los datos e intente nuevamente";
		}
		return resp;
	}

	public String eliminarCliente(String documento) {
		com.medicinata.dao.ClienteDao miClienteDaoJpa = new com.medicinata.dao.ClienteDao();

		String resp = "";

		Cliente cliente = miClienteDaoJpa.consultarCliente(documento);

		if (cliente != null) {
			resp = miClienteDaoJpa.eliminarCliente(cliente);
		} else {
			resp ="El cliente no existe o lo ingreso incorrectamente";
		}
		return resp;
	}

}
