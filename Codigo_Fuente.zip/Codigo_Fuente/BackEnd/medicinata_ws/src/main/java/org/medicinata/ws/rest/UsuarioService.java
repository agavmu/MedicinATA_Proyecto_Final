package org.medicinata.ws.rest;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.medicinata.ws.vo.UsuarioVo;

import com.medicinata.entidades.Usuario;

import org.medicinata.ws.dao.UsuarioDao;

@Path("usuarios")
public class UsuarioService {

	UsuarioDao usuarioDao = new UsuarioDao();

	// http://localhost:8080/medicinata_ws/webapi/usuarios/validarlogin
	@POST
	@Path("/validarlogin")
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public Response validarLogin(UsuarioVo usuarioVo) {
		try {
			usuarioVo = usuarioDao.consultarLogin(usuarioVo.getEmail(), usuarioVo.getClave());
			if (usuarioVo != null) {
				return Response.ok().entity(usuarioVo).build();
			} else {
				return Response.status(Response.Status.NOT_FOUND).build();
			}
		} catch (Exception e) {
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}

	// http://localhost:8080/medicinata_ws/webapi/usuarios/registrar
	@POST
	@Path("/registrar")
	@Consumes({ MediaType.APPLICATION_JSON })
	public Response registrarUsuario(Usuario usuario) {
		try {
			String resp = usuarioDao.registrarUsuario(usuario);
			if (resp.equals("Usuario registrado")) {
				return Response.ok().entity(usuario).build();
			} else {
				return Response.status(Response.Status.NOT_FOUND).build();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}

	// http://localhost:8080/medicinata_ws/webapi/usuarios/{id}
	@GET
	@Path("/{id}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response consultarUsuario(@PathParam("id") String documento) {
		UsuarioVo usuario = usuarioDao.consultaIndividual(documento);
		if (usuario != null) {
			return Response.ok(usuario).build();
		}
		return Response.status(Response.Status.NOT_FOUND).build();
	}

	// http://localhost:8080/medicinata_ws/webapi/usuarios/usuarios
	@GET
	@Path("/usuarios")
	@Produces({ MediaType.APPLICATION_JSON })
	public List<UsuarioVo> obtenerListaUsuarios() {
		return usuarioDao.obtenerListaUsuarios();
	}

	// http://localhost:8080/medicinata_ws/webapi/usuarios/{id}
	@PUT
	@Path("/{id}")
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	public Response actualizarUsuario(@PathParam("id") String documento, Usuario usuario) {
		try {
			String resp = usuarioDao.actualizarUsuario(documento, usuario);
			if (resp.equals("Usuario actualizado")) {
				return Response.ok(usuario).build();
			} else {
				return Response.status(Response.Status.NOT_FOUND).build();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}

	// http://localhost:8080/medicinata_ws/webapi/usuarios/{id}
	@DELETE
	@Path("/{id}")
	public Response eliminarUsuario(@PathParam("id") String documento) {
		try {
			String resp = usuarioDao.eliminarUsuario(documento);
			if (resp.equals("Usuario eliminado")) {
				return Response.ok().build();
			} else {
				return Response.status(Response.Status.NOT_FOUND).header("header", resp).build();
			}

		} catch (Exception e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}
}
