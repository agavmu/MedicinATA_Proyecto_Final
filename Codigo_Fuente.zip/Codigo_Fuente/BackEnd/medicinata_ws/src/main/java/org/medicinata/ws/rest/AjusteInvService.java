package org.medicinata.ws.rest;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.medicinata.ws.dao.AjusteInvDao;
import org.medicinata.ws.vo.AjusteInvVo;

import com.medicinata.entidades.AjusteInv;

@Path("/ajustesinventario")
public class AjusteInvService {

	AjusteInvDao ajusteInvDao = new AjusteInvDao();

	// http://localhost:8080/medicinata_ws/webapi/ajusteinvdetalle/registrarcompra
	@POST
	@Path("/registrarcompra")
	@Consumes({ MediaType.APPLICATION_JSON })
	public Response registrarCompra(AjusteInv medicamento) {
		try {
			String resp = ajusteInvDao.registrarCompra(medicamento);
			if (resp.equals("Compra realizada satisfactoriamente")) {
				return Response.ok().entity(medicamento).build();
			} else {
				return Response.status(Response.Status.NOT_FOUND).build();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}

	// http://localhost:8080/medicinata_ws/webapi/ajustesinventario/ajuste/{id}
	@GET
	@Path("/ajuste/{id}")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response consutarAjuste(@PathParam("id") Long idajuste) {
		AjusteInvVo ajuste = ajusteInvDao.consultaAjuste(idajuste);

		if (ajuste != null) {
			return Response.ok(ajuste).build();
		}
		return Response.status(Response.Status.NOT_FOUND).build();
	}

	// http://localhost:8080/medicinata_ws/webapi/ajustesinventario/ajustes
	@GET
	@Path("/ajustes")
	@Produces({ MediaType.APPLICATION_JSON })
	public List<AjusteInvVo> obtenerListaAjustes() {
		return ajusteInvDao.obtenerListaAjustes();
	}

	// http://localhost:8080/medicinata_ws/webapi/ajustesinventario/{id}
	@PUT
	@Path("/{id}")
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	public Response actualizarAjuste(@PathParam("id") Long idajuste, AjusteInv ajusteinv) {
		try {
			String resp = ajusteInvDao.actualizarAjuste(idajuste, ajusteinv);
			if (resp.equals("Ajuste actualizado")) {
				return Response.ok(ajusteinv).build();
			} else {
				return Response.status(Response.Status.NOT_FOUND).build();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}
	}

}
