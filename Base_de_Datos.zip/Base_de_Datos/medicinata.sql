CREATE DATABASE  IF NOT EXISTS `medicinata` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `medicinata`;
-- MySQL dump 10.13  Distrib 8.0.20, for macos10.15 (x86_64)
--
-- Host: localhost    Database: medicinata
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ajustesinventario`
--

DROP TABLE IF EXISTS `ajustesinventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ajustesinventario` (
  `idajuste` int NOT NULL AUTO_INCREMENT,
  `fecha` datetime DEFAULT NULL,
  `precio` float DEFAULT NULL,
  `observaciones` varchar(1000) DEFAULT NULL,
  `cliente` char(20) DEFAULT NULL,
  `usuario` char(20) DEFAULT NULL,
  PRIMARY KEY (`idajuste`),
  KEY `Cliente` (`cliente`),
  KEY `Usuario` (`usuario`),
  CONSTRAINT `ajustesinventario_ibfk_1` FOREIGN KEY (`cliente`) REFERENCES `clientes` (`documento`),
  CONSTRAINT `ajustesinventario_ibfk_2` FOREIGN KEY (`usuario`) REFERENCES `usuarios` (`documento`)
) ENGINE=InnoDB AUTO_INCREMENT=23763 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ajustesinventario`
--

LOCK TABLES `ajustesinventario` WRITE;
/*!40000 ALTER TABLE `ajustesinventario` DISABLE KEYS */;
INSERT INTO `ajustesinventario` VALUES (2768,'2020-11-10 07:15:47',4000,'El medicamento no se estaba vendiendo y hay mucho en las reservas asi que decidi bajer el precio','16541208','16490507'),(3728,'2020-11-08 18:53:20',4000,'Debido a que el medicamento se esta agotando y no podemos conseguir mas reservas se aumento el precio','16840112','16120222'),(23762,'2020-11-10 12:03:20',3500,'Se aumento el precio del medicamento debido a que se subio el cobro del medicamento','16730118','16240718');
/*!40000 ALTER TABLE `ajustesinventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ajustesinventariodetalle`
--

DROP TABLE IF EXISTS `ajustesinventariodetalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ajustesinventariodetalle` (
  `idajustesinvdetalle` int NOT NULL AUTO_INCREMENT,
  `idajuste` int DEFAULT NULL,
  `codigocum` int DEFAULT NULL,
  `cantidad` int DEFAULT NULL,
  `precio` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idajustesinvdetalle`),
  KEY `idajuste` (`idajuste`),
  KEY `codigocum` (`codigocum`),
  CONSTRAINT `idajustesinvdetalle_fk_1` FOREIGN KEY (`idajuste`) REFERENCES `ajustesinventario` (`idajuste`),
  CONSTRAINT `idajustesinvdetalle_fk_2` FOREIGN KEY (`codigocum`) REFERENCES `cum` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=8771 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ajustesinventariodetalle`
--

LOCK TABLES `ajustesinventariodetalle` WRITE;
/*!40000 ALTER TABLE `ajustesinventariodetalle` DISABLE KEYS */;
/*!40000 ALTER TABLE `ajustesinventariodetalle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `documento` char(20) NOT NULL,
  `razonsocial` varchar(45) DEFAULT NULL,
  `telefono` char(20) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `Clave` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`documento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES ('16541208','Farmacia AGavmu','+57-303-685-8292','et.ipsum@tinciduntdui.com','Apdo.:386-2389 Vel Avenida',NULL),('16730118','Farmacia Anfepim','+57-302-698-9870','fames.ac@tristique.ca','525-6830 Auctor, Av.',NULL),('16840112','Farmacia Ubecor','+57-300-715-7951','nunc@loremsemper.net','6726 Venenatis Ctra.',NULL);
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cum`
--

DROP TABLE IF EXISTS `cum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cum` (
  `codigo` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) DEFAULT NULL,
  `concentracion` varchar(45) DEFAULT NULL,
  `descripcion` varchar(250) DEFAULT NULL,
  `observaciones` varchar(1000) DEFAULT NULL,
  `img` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cum`
--

LOCK TABLES `cum` WRITE;
/*!40000 ALTER TABLE `cum` DISABLE KEYS */;
INSERT INTO `cum` VALUES (1,'Dormicum Ampollas','15mg/3ml','Midazolam utilizada como ansiolítico o en procesos ligeramente dolorosos, aunque no tiene efecto analgesico ni anestesico','Midazolam puede causar mucha somnolencia, mareo, o sensación de desvanecimiento. Estos efectos pueden durar más tiempo en los adultos mayores. Tenga mucho cuidado para evitar caídas o lesiones accidentales después de haber recibido midazolam injection.','dormi.png'),(2,'Ibuprofeno Suspension','100mg/5ml','Ibuprofeno ibuprofeno es un antiinflamatorio no esteroideo, utilizado frecuentemente como antipirético, analgésico y antiinflamatorio','El Ibuprofeno se usa para tratar la fiebre y/o el dolor, bloquea la producción y la liberación de sustancias químicas del cuerpo que causan dolor e inflamación.','ibuprofeno.png'),(3,'Ibuprofeno Suspension','100mg/5ml','Ibuprofeno ibuprofeno es un antiinflamatorio no esteroideo, utilizado frecuentemente como antipirético, analgésico y antiinflamatorio','El Ibuprofeno se usa para tratar la fiebre y/o el dolor, bloquea la producción y la liberación de sustancias químicas del cuerpo que causan dolor e inflamación.','ibuprofeno.png'),(4,'acetaminofen','200mg','Pastilla acetaminofen','Una pastilla que recomiendan los doctores para cualquier dolor','acetaminofen.jpg'),(5,'acetaminofen','200mg','Pastilla acetaminofen','Una pastilla que recomiendan los doctores para cualquier dolor','acetaminofen.jpg'),(6,'acetaminofen','200mg','Pastilla acetaminofen','Una pastilla que recomiendan los doctores para cualquier dolor','acetaminofen.jpg'),(7,'acetaminofen','200mg','Pastilla acetaminofen','Una pastilla que recomiendan los doctores para cualquier dolor','acetaminofen.jpg'),(8,'Alopurinol','300mg','Alopurinol es un compuesto químico empleado como medicamento frente a la hiperuricemia y sus complicaciones, como la gota.​','El Alopurinol sirve para la prevención de nefropatía por ácido úrico durante la terapia intensiva de la enfermedad neoplásica, se recomienda el tratamiento con 600 a 800 mg/día durante dos o tres días, concomitante con una alta ingesta de líquidos.','alopurinol.jpg'),(9,'Alopurinol','300mg','Alopurinol es un compuesto químico empleado como medicamento frente a la hiperuricemia y sus complicaciones, como la gota.​','El Alopurinol sirve para la prevención de nefropatía por ácido úrico durante la terapia intensiva de la enfermedad neoplásica, se recomienda el tratamiento con 600 a 800 mg/día durante dos o tres días, concomitante con una alta ingesta de líquidos.','alopurinol.jpg'),(10,'Amoxicilina','500mg','Amoxicilina Cada capsula dura contiene amoxicilina trihidrato equivalente a 500 mg de amoxicilina','La Amoxicilina se usa para tratar algunas infecciones provocadas por bacterias como la neumonía; la bronquitis e infecciones de los oídos, nariz, garganta, del tracto urinario y la piel','amoxi.jpg'),(11,'Amoxicilina','500mg','Amoxicilina Cada capsula dura contiene amoxicilina trihidrato equivalente a 500 mg de amoxicilina','La Amoxicilina se usa para tratar algunas infecciones provocadas por bacterias como la neumonía; la bronquitis e infecciones de los oídos, nariz, garganta, del tracto urinario y la piel','amoxi.jpg'),(12,'Amoxicilina','500mg','Amoxicilina Cada capsula dura contiene amoxicilina trihidrato equivalente a 500 mg de amoxicilina','La Amoxicilina se usa para tratar algunas infecciones provocadas por bacterias como la neumonía; la bronquitis e infecciones de los oídos, nariz, garganta, del tracto urinario y la piel','amoxi.jpg'),(13,'Salbutamol Jarabe','40mg/100ml','El Salbutamol relaja los músculos de las paredes de las pequeñas vías aéreas de los pulmones','El Salbutamol Jarabe ayuda a abrir las vías respiratorias y aliviar la opresión en el pecho, las sibilancias y la tos, a fin de que su niño pueda respirar más fácilmente.','salbutamol.jpg'),(14,'Salbutamol Jarabe','40mg/100ml','El Salbutamol relaja los músculos de las paredes de las pequeñas vías aéreas de los pulmones','El Salbutamol Jarabe ayuda a abrir las vías respiratorias y aliviar la opresión en el pecho, las sibilancias y la tos, a fin de que su niño pueda respirar más fácilmente.','salbutamol.jpg'),(15,'acetaminofen','200mg','Pastilla acetaminofen','Una pastilla que recomiendan los doctores para cualquier dolor','acetaminofen.jpg'),(55,'Levotiroxina','200mg','Levotiroxina','levotiroxina','acetaminofen.jpg');
/*!40000 ALTER TABLE `cum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicamentos_clientes`
--

DROP TABLE IF EXISTS `medicamentos_clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicamentos_clientes` (
  `idmedicamento` int NOT NULL AUTO_INCREMENT,
  `cliente` char(20) DEFAULT NULL,
  `codigocum` int DEFAULT NULL,
  `cantidad` int DEFAULT NULL,
  `precio` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idmedicamento`),
  KEY `cliente` (`cliente`),
  KEY `codigocum` (`codigocum`),
  CONSTRAINT `medicamentos_fk_1` FOREIGN KEY (`cliente`) REFERENCES `clientes` (`documento`),
  CONSTRAINT `medicamentos_fk_2` FOREIGN KEY (`codigocum`) REFERENCES `cum` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=8821 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicamentos_clientes`
--

LOCK TABLES `medicamentos_clientes` WRITE;
/*!40000 ALTER TABLE `medicamentos_clientes` DISABLE KEYS */;
INSERT INTO `medicamentos_clientes` VALUES (8773,'16541208',1,2,'300'),(8774,'16730118',2,3,'500'),(8775,'16840112',3,138,'150'),(8776,'16840112',4,784,'200'),(8777,'16730118',5,124,'150'),(8778,'16730118',6,326,'150'),(8779,'16541208',7,315,'200'),(8780,'16541208',8,252,'500'),(8781,'16541208',9,137,'350'),(8782,'16840112',10,1953,'300'),(8783,'16840112',11,18,'450'),(8784,'16730118',12,6,'150'),(8785,'16730118',13,3,'200'),(8786,'16730118',14,6,'550'),(8787,'16840112',15,5,'400'),(8820,'16541208',55,6,'250');
/*!40000 ALTER TABLE `medicamentos_clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `documento` char(20) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `apellido` varchar(150) DEFAULT NULL,
  `clave` varchar(64) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `telefono` char(30) DEFAULT NULL,
  `tipousuario` int DEFAULT NULL,
  PRIMARY KEY (`documento`),
  KEY `FK` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES ('1','marco luis','gomez','123','marco@gmail.com','3032750340',2),('1083','pepe','perez','123','pepe@gmail.com','3081393514',4),('1424','violet','zapata','123','violet@gmail.com','3041936513',3),('16120222','Jescie','gonzales','Z6571','jescie@gmail.com','3015073095',1),('16240718','Kyra','gaviria','123','kyra@gmail.com','3027828205',1),('16490507','Lucian','morales','434479','lucian@gmail.com','3095339077',1),('16770908','Buckminster','pulido','40401','buck@gmail.com','3023583222',2),('1917','Ubeiman','Cortez','123','ubeiman@gmail.com','3103591795',1),('1983','Andres','Felipe','123','andres@gmail.com','3081937515',1),('2','lunia','fernandez','123','lunia@gmail.com','3081936513',2),('3245','juan','petito','1234','juan@gmail.com','3018295719',2),('4','Adrian','Gaviria','123','adrian@gmail.com','3015931689',1),('444','julio','zapata','123','julio@gmail.com','3017031762',2),('846','klevin','quintero','123','klevin@gmail.com','3013571858',2);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-07 16:44:17
