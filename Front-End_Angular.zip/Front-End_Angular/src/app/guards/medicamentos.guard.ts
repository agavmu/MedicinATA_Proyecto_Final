import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class MedicamentosGuard implements CanActivate {  

  constructor( public auth : AuthService, private route: Router ) {
  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

      parseInt(localStorage.getItem('tipo'));

      if(localStorage.getItem('tipo') === '2'){
        return true;
      }else if(localStorage.getItem('tipo') === '3'){
        return true;
      }else if(localStorage.getItem('tipo') === '1' || '4'){
        this.route.navigate(['/home'])
        return false;
      }
      return false;
  }
  
}
