import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class HomeGuard implements CanActivate {

  constructor( public auth : AuthService, private route: Router ) {
  }

  canActivate(
    next: ActivatedRouteSnapshot, 
    state: RouterStateSnapshot): 
    Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree 
    {
          
    return new Promise((resolve, reject) => {

      this.auth.isLoggedIn().subscribe(
        user => {
        if (user) {
          resolve(true);
        } else {
          console.log('User is not logged in');
          this.route.navigate(['/']);
          resolve(false);
        }
      });
    });
      
  }

}
