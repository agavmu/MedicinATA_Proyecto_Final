import { TestBed } from '@angular/core/testing';

import { MedicamentosGuard } from './medicamentos.guard';

describe('MedicamentosGuard', () => {
  let guard: MedicamentosGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(MedicamentosGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
