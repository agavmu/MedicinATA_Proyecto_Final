import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ClientesGuard implements CanActivate {
  
  tipo =toString();

  constructor( public auth : AuthService, private route: Router ) {
  }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      
      parseInt(localStorage.getItem('tipo'));

      if(localStorage.getItem('tipo') === '1'){
        return true;
      }else if(localStorage.getItem('tipo') === '2' || '3' || '4'){
        this.route.navigate(['/home'])
        return false;
      }
  }
}