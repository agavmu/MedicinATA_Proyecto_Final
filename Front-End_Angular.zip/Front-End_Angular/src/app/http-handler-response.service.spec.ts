import { TestBed } from '@angular/core/testing';

import { HttpHandlerResponseService } from './http-handler-response.service';

describe('HttpHandlerResponseService', () => {
  let service: HttpHandlerResponseService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HttpHandlerResponseService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
