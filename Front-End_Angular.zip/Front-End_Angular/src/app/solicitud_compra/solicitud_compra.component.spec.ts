import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SolicompraComponent } from './solicitud_compra.component';

describe('SolicompraComponent', () => {
  let component: SolicompraComponent;
  let fixture: ComponentFixture<SolicompraComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SolicompraComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SolicompraComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
