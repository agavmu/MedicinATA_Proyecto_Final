import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ClientService } from '../client.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  form: FormGroup;
  load: boolean = true;

  urlMedicamento = ['./assets/medicamento1.jpg', './assets/medicamento2.jpg', './assets/medicamento3.jpg'];
              

  diccionario = {'./assets/medicamento1.jpg': {precio: 20000, nombre: "Pastillas antiestres"}, 
                './assets/medicamento2.jpg': {precio: 15000, nombre: "Pastillas para el dolor de cabeza"},
                 './assets/medicamento3.jpg': {precio: 10500, nombre: "Colibre para la gastritis"}}          

  constructor(private fb: FormBuilder, private client: ClientService, public auth: AuthService, private route: Router) { }

  ngOnInit(): void {

    this.auth.controlsesion();
    
  }

}