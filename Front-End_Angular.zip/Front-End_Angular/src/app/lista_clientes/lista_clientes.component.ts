import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-lista_clientes',
  templateUrl: './lista_clientes.component.html',
  styleUrls: ['./lista_clientes.component.css']
})
export class ClientesComponent implements OnInit { 

  title = 'datatables';
  dtOptions: DataTables.Settings = {};
  clientes: any[];

  constructor(private client: ClientService, public auth: AuthService, private route: Router) { }

  ngOnInit(): void {
    
    this.auth.controlsesion();

    this.client.getRequest('http://localhost:8080/medicinata_ws/webapi/clientes/clientes',
    ).subscribe((result: any) => {
      console.log(result.body)
      this.clientes = (result.body);
      console.log('Clientes', this.clientes)
    });

    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 4,
      language: {
        url: "//cdn.datatables.net/plug-ins/1.10.21/i18n/Spanish.json"
      }
    };
  }

}