import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-lista_medicamentos',
  templateUrl: './lista_medicamentos.component.html',
  styleUrls: ['./lista_medicamentos.component.css']
})
export class MedicamentosComponent implements OnInit {

  form: FormGroup;
  title = 'datatables';
  dtOptions: DataTables.Settings = {};
  medicamentos: any[];


  constructor(private fb: FormBuilder, private client: ClientService, public auth: AuthService, private route: Router) {
    this.medicamentos = [];
    this.medicamentos['detalles'] = [];
    console.log(this.medicamentos);

  }

  ngOnInit(): void {

    this.auth.controlsesion();

    this.client.getRequest('http://localhost:8080/medicinata_ws/webapi/medicamentos/medicamentos',
    ).subscribe((result: any) => {
      console.log(result.body)
      this.medicamentos = (result.body);
      console.log('Medicamentos', this.medicamentos)
    });

    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 4,
      scrollX: (window.screen.width < 1024),
      language: {
        url: "//cdn.datatables.net/plug-ins/1.10.21/i18n/Spanish.json"
      }
    };
  }
}