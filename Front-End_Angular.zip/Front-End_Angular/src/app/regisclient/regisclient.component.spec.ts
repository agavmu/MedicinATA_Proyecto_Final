import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisclientComponent } from './regisclient.component';

describe('RegisclientComponent', () => {
  let component: RegisclientComponent;
  let fixture: ComponentFixture<RegisclientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisclientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisclientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
