import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavComponent } from './nav/nav.component';
import { FooterComponent } from './footer/footer.component';
import { BienvenidaComponent } from './bienvenida/bienvenida.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { RegistrouserComponent } from './registrouser/registrouser.component';
import { ClientesComponent } from "./lista_clientes/lista_clientes.component";
import { MedicamentosComponent } from "./lista_medicamentos/lista_medicamentos.component";
import { AcercadeComponent } from "./acercade/acercade.component";
import { MedicamentosDispComponent } from './medicamentos_disp/medicamentos_disp.component';
import { StatsComponent } from './estadisticas_med/estadisticas_med.component';
import { NotifyComponent } from './notificaciones_solic/notificaciones_solic.component';
import { SolicompraComponent } from './solicitud_compra/solicitud_compra.component';
import { ProfileClientComponent } from './profile_client/profile_client.component';
import { AddMedicineComponent } from './add_medicine/add_medicine.component';
import { DataTablesModule } from 'angular-datatables';
import { ChangePasswordComponent } from './change_password/change_password.component';
import { RegisadminComponent } from './regisadmin/regisadmin.component';
import { ImgComponent } from './img/img.component';
import { RegisclientComponent } from './regisclient/regisclient.component';

@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    FooterComponent,
    BienvenidaComponent,
    LoginComponent,
    HomeComponent,
    RegistrouserComponent,
    ClientesComponent,
    MedicamentosComponent,
    AcercadeComponent,
    MedicamentosDispComponent,
    StatsComponent,
    NotifyComponent,
    SolicompraComponent,
    ProfileClientComponent,
    AddMedicineComponent,
    ChangePasswordComponent,
    RegisadminComponent,
    ImgComponent,
    RegisclientComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    DataTablesModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
