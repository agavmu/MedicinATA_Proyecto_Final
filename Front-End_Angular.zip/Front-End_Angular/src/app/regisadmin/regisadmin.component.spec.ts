import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisadminComponent } from './regisadmin.component';

describe('RegisadminComponent', () => {
  let component: RegisadminComponent;
  let fixture: ComponentFixture<RegisadminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisadminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisadminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
