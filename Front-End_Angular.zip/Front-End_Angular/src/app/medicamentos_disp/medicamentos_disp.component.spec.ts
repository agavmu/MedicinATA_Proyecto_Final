import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicamentosDispComponent } from './medicamentos_disp.component';

describe('MedicamentosDispComponent', () => {
  let component: MedicamentosDispComponent;
  let fixture: ComponentFixture<MedicamentosDispComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicamentosDispComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicamentosDispComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
