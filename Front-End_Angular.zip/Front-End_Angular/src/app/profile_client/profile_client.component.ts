import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service';
import { AuthService } from '../auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-profile_client',
  templateUrl: './profile_client.component.html',
  styleUrls: ['./profile_client.component.css']
})
export class ProfileClientComponent implements OnInit {    

  // form: FormGroup;

  usuario: {
    documento: string,
    nombre: string,
    apellido: string,
    email: string,
    telefono: string,
    clave: string,
    tipo: number,
  };

  constructor(private fb: FormBuilder, private client: ClientService, public auth: AuthService, private route: Router) { 
    this.usuario = {
      documento: null,
      nombre: null,
      apellido: null,
      email: null,
      telefono: null,
      clave: null,
      tipo: null,
    };
  }

  ngOnInit(): void {
    this.client.getRequest('http://localhost:8080/medicinata_ws/webapi/usuarios/' + localStorage.getItem('documento'), 
      localStorage.getItem("token")).subscribe((response: any) => {
        this.usuario = (response.body);
      });
  }

  async onSubmit() {

    console.log(this.usuario);
    
    if (this.usuario.apellido != null) {

      this.client.putRequest('http://localhost:8080/medicinata_ws/webapi/usuarios/' + localStorage.getItem('documento'), {
        documento: this.usuario.documento,     
        nombre: this.usuario.nombre,
        apellido: this.usuario.apellido,
        email: this.usuario.email,
        telefono: String(this.usuario.telefono),
        clave: this.usuario.clave,
        tipo: this.usuario.tipo
      },

        localStorage.getItem("token")
      ).subscribe(

        (response: any) => {
          console.log(response);
          if (response) {
            Swal.fire({
              icon: 'success',
              title: 'Actualizado',
              timer: 2000,
              timerProgressBar: true,
              toast: true,
              position: 'top-end',
            })
            this.route.navigate(['/profileClient']);
          } else {
            Swal.fire({
              icon: 'question',
              title: 'Hubo un error',
              timer: 2000,
              timerProgressBar: true,
            })
          }
        }, (error) => {
          Swal.fire({
            icon: 'warning',
            title: 'Hubo un error, intente nuevamente',
            timer: 2000,
            timerProgressBar: true,
          })
        });
    } else {
      Swal.fire({
        icon: 'question',
        title: 'Verifique el formulario e intente nuevamente',
        timer: 2000,
        timerProgressBar: true,
      })
    }
  }
}